local Addon = FojjiCoreNS
if not Addon then return end
local FDJ = Addon.DJ

local L = FDJ.L

local Bis = {}
FDJ.Bis = Bis

Bis.GROUPS = {
    { key = "head", slots = { 1 }, label = "HEADSLOT", locs = { INVTYPE_HEAD = true } },
    { key = "neck", slots = { 2 }, label = "NECKSLOT", locs = { INVTYPE_NECK = true } },
    { key = "shoulder", slots = { 3 }, label = "SHOULDERSLOT", locs = { INVTYPE_SHOULDER = true } },
    { key = "back", slots = { 15 }, label = "BACKSLOT", locs = { INVTYPE_CLOAK = true } },
    { key = "chest", slots = { 5 }, label = "CHESTSLOT", locs = { INVTYPE_CHEST = true, INVTYPE_ROBE = true } },
    { key = "wrist", slots = { 9 }, label = "WRISTSLOT", locs = { INVTYPE_WRIST = true } },
    { key = "hands", slots = { 10 }, label = "HANDSSLOT", locs = { INVTYPE_HAND = true } },
    { key = "waist", slots = { 6 }, label = "WAISTSLOT", locs = { INVTYPE_WAIST = true } },
    { key = "legs", slots = { 7 }, label = "LEGSSLOT", locs = { INVTYPE_LEGS = true } },
    { key = "feet", slots = { 8 }, label = "FEETSLOT", locs = { INVTYPE_FEET = true } },
    { key = "rings", slots = { 11, 12 }, label = "FINGER0SLOT", locs = { INVTYPE_FINGER = true } },
    { key = "trinkets", slots = { 13, 14 }, label = "TRINKET0SLOT", locs = { INVTYPE_TRINKET = true } },
    { key = "mainhand", slots = { 16 }, label = "MAINHANDSLOT",
      locs = { INVTYPE_WEAPON = true, INVTYPE_2HWEAPON = true, INVTYPE_WEAPONMAINHAND = true } },
    { key = "offhand", slots = { 17 }, label = "SECONDARYHANDSLOT",
      locs = { INVTYPE_SHIELD = true, INVTYPE_HOLDABLE = true, INVTYPE_WEAPONOFFHAND = true } },
    { key = "ranged", slots = { 18 }, label = "RANGEDSLOT",
      locs = { INVTYPE_RANGED = true, INVTYPE_RANGEDRIGHT = true, INVTYPE_THROWN = true, INVTYPE_RELIC = true } },
    { key = "tabard", slots = { 19 }, label = "TABARDSLOT", locs = { INVTYPE_TABARD = true }, optional = true },
}

function Bis.TotalSlots()
    local n = 0
    for _, g in ipairs(Bis.GROUPS) do n = n + #g.slots end
    return n
end
local BY_KEY = {}
for _, g in ipairs(Bis.GROUPS) do BY_KEY[g.key] = g end

local FALLBACK_LABEL = {
    HEADSLOT = "Head", NECKSLOT = "Neck", SHOULDERSLOT = "Shoulder", BACKSLOT = "Back", CHESTSLOT = "Chest",
    WRISTSLOT = "Wrist", HANDSSLOT = "Hands", WAISTSLOT = "Waist", LEGSSLOT = "Legs", FEETSLOT = "Feet",
    FINGER0SLOT = "Rings", TRINKET0SLOT = "Trinkets", MAINHANDSLOT = "Main Hand",
    SECONDARYHANDSLOT = "Off Hand", RANGEDSLOT = "Ranged", TABARDSLOT = "Tabard",
}

function Bis.Label(group)
    if group.key == "rings" then return L.BIS_RINGS end
    if group.key == "trinkets" then return L.BIS_TRINKETS end
    return _G[group.label] or FALLBACK_LABEL[group.label] or group.key
end

function Bis.Wants(group)
    return #group.slots
end

local function owner(charKey)
    return charKey and FDJ.db and FDJ.db.chars[charKey] or FDJ.char
end

local SPEC_ICONS = {
    WARRIOR = { arms = 132355, fury = 132347, protection = 132341 },
    PALADIN = { holy = 135920, protection = 135893, retribution = 135873 },
    HUNTER = { beastmastery = 461112, marksmanship = 236179, survival = 461113 },
    ROGUE = { assassination = 236270, combat = 236286, subtlety = 132320 },
    PRIEST = { discipline = 135940, holy = 237542, shadow = 136207 },
    SHAMAN = { elemental = 136048, enhancement = 237581, restoration = 136052 },
    MAGE = { arcane = 135932, fire = 135810, frost = 135846 },
    WARLOCK = { affliction = 136145, demonology = 136172, destruction = 136186 },
    DRUID = { balance = 136096, feralcombat = 132115, restoration = 136041 },
}

local function classOf(charKey)
    local o = owner(charKey)
    if o and o.class then return o.class end
    local _, c = UnitClass("player")
    return c
end

function Bis.Specs(charKey)
    local class = classOf(charKey)
    local out = {}
    local markers = FojjiCore and FojjiCore.SpecMarkers and FojjiCore.SpecMarkers[class] or {}
    local mine = not charKey or charKey == FDJ.charKey
    for i, m in ipairs(markers) do
        local icon = SPEC_ICONS[class] and SPEC_ICONS[class][m[1]]
        if mine and GetTalentTabInfo then
            local r = { pcall(GetTalentTabInfo, i) }
            local tex = r[1] and (type(r[2]) == "number" and r[5] or r[3])
            if tex and (type(tex) == "number" or type(tex) == "string") then icon = icon or tex end
        end
        out[#out + 1] = { key = m[1], name = m[2], icon = icon or 134400 }
    end
    return out
end

local function detected()
    local spec = FojjiCore and FojjiCore.GetSpec and FojjiCore.GetSpec()
    return spec and spec.key
end

local function specOf(charKey)
    local o = owner(charKey)
    if o and o.bisSpec then return o.bisSpec end
    local mine = not charKey or charKey == FDJ.charKey
    local specs = Bis.Specs(charKey)
    return (mine and detected()) or (specs[1] and specs[1].key) or "any"
end
Bis.SpecOf = specOf

local function lists(charKey)
    local o = owner(charKey)
    if not o then return { { name = "?", picks = {} } }, 1 end
    if type(o.bisLists) ~= "table" or #o.bisLists == 0 then
        o.bisLists = { { name = L.BIS_LIST_DEFAULT, picks = type(o.bis) == "table" and o.bis or {} } }
        o.bisActive = 1
        o.bis = nil
    end
    local spec = specOf(charKey)
    o.bisSpec = spec
    for _, l in ipairs(o.bisLists) do l.spec = l.spec or spec end
    local active = tonumber(o.bisActive) or 1
    local cur = o.bisLists[active]
    if not cur or cur.spec ~= spec then
        active = nil
        o.bisBySpec = o.bisBySpec or {}
        local remembered = o.bisBySpec[spec]
        if remembered and o.bisLists[remembered] and o.bisLists[remembered].spec == spec then active = remembered end
        if not active then
            for i, l in ipairs(o.bisLists) do
                if l.spec == spec then active = i break end
            end
        end
        if not active then
            o.bisLists[#o.bisLists + 1] = { name = L.BIS_LIST_DEFAULT, spec = spec, picks = {} }
            active = #o.bisLists
        end
    end
    o.bisActive = active
    return o.bisLists, active
end
Bis.Lists = lists

local function store(charKey)
    local all, active = lists(charKey)
    local list = all[active]
    list.picks = list.picks or {}
    return list.picks
end
Bis.Store = store

local function changedLists()
    FDJ:Emit("FDJ_WISHES")
end

function Bis.ActiveName(charKey)
    local all, active = lists(charKey)
    return all[active].name, active, #all
end

function Bis.SpecLists(charKey)
    local all, active = lists(charKey)
    local spec = specOf(charKey)
    local out = {}
    for i, l in ipairs(all) do
        if l.spec == spec then out[#out + 1] = { index = i, name = l.name, picks = l.picks, active = i == active } end
    end
    return out
end

function Bis.SetSpec(key, charKey)
    local o = owner(charKey)
    if not o or not key then return end
    o.bisSpec = key
    lists(charKey)
    changedLists()
end

function Bis.SetActive(index, charKey)
    local o = owner(charKey)
    local all = lists(charKey)
    local l = all[index]
    if not l then return end
    o.bisSpec = l.spec
    o.bisActive = index
    o.bisBySpec = o.bisBySpec or {}
    o.bisBySpec[l.spec] = index
    changedLists()
end

function Bis.MoveList(from, to, charKey)
    local o = owner(charKey)
    local all, active = lists(charKey)
    if from == to or not all[from] or not all[to] then return end
    local l = table.remove(all, from)
    table.insert(all, to, l)
    if active == from then
        o.bisActive = to
    elseif from < active and to >= active then
        o.bisActive = active - 1
    elseif from > active and to <= active then
        o.bisActive = active + 1
    end
    o.bisBySpec = nil
    changedLists()
end

local function copy(picks)
    local out = {}
    for key, ids in pairs(picks or {}) do
        out[key] = {}
        for i, id in ipairs(ids) do out[key][i] = id end
    end
    return out
end

function Bis.FreeName(name, charKey)
    local taken = {}
    for _, l in ipairs(Bis.SpecLists(charKey)) do taken[l.name] = true end
    local final, k = name, 2
    while taken[final] do
        final = name .. " " .. k
        k = k + 1
    end
    return final
end

function Bis.NewList(name, fromCurrent, charKey)
    local all, active = lists(charKey)
    all[#all + 1] = { name = name, spec = specOf(charKey), picks = fromCurrent and copy(all[active].picks) or {} }
    Bis.SetActive(#all, charKey)
end

function Bis.RenameList(name, charKey)
    local all, active = lists(charKey)
    if name and name ~= "" then all[active].name = name end
    changedLists()
end

function Bis.DeleteListAt(index, charKey)
    local o = owner(charKey)
    local all, active = lists(charKey)
    local l = all[index]
    if not l then return end
    if index == active then return Bis.DeleteList(charKey) end
    table.remove(all, index)
    o.bisActive = index < active and active - 1 or active
    o.bisBySpec = nil
    changedLists()
end

function Bis.DeleteSave(key)
    local data = FDJ.db and FDJ.db.chars[key]
    if not data or key == FDJ.charKey then return end
    data.bisLists, data.bis, data.bisActive, data.bisSpec, data.bisBySpec = nil, nil, nil, nil, nil
    if not key:match("%-%x%x%x%x%x%x+$") then FDJ.db.chars[key] = nil end
    changedLists()
end

function Bis.DeleteList(charKey)
    local o = owner(charKey)
    local all, active = lists(charKey)
    local spec = all[active].spec
    local others = 0
    for _, l in ipairs(all) do if l.spec == spec then others = others + 1 end end
    if others <= 1 then
        all[active].picks = {}
    else
        table.remove(all, active)
        o.bisActive = nil
        o.bisBySpec = nil
    end
    changedLists()
end

local function equipLoc(itemID)
    if not itemID then return nil end
    if C_Item and C_Item.GetItemInfoInstant then
        local _, _, _, loc = C_Item.GetItemInfoInstant(itemID)
        return loc
    end
    if GetItemInfoInstant then
        local _, _, _, loc = GetItemInfoInstant(itemID)
        return loc
    end
end

function Bis.GroupFor(itemID)
    local loc = equipLoc(itemID)
    if not loc or loc == "" then return nil end
    for _, g in ipairs(Bis.GROUPS) do
        if g.locs[loc] then return g end
    end
end

function Bis.Find(itemID, charKey)
    if not itemID then return nil end
    for key, list in pairs(store(charKey)) do
        for rank, id in ipairs(list) do
            if id == itemID then return BY_KEY[key], rank end
        end
    end
end

local DEFAULTS = { enabled = true, key = "SHIFT-L", tooltip = true, alerts = true, altClick = true, autoSuggest = true, gearScore = true }

function Bis.Options()
    if not FDJ.db then return DEFAULTS end
    local o = FDJ.db.bisOptions
    if type(o) ~= "table" then
        o = {}
        FDJ.db.bisOptions = o
    end
    for k, v in pairs(DEFAULTS) do
        if o[k] == nil then o[k] = v end
    end
    return o
end

function Bis.On()
    return not FDJ.off and Bis.Options().enabled ~= false
end

function Bis.Set(key, value)
    Bis.Options()[key] = value
    if key == "key" or key == "enabled" then Bis.ApplyKey() end
    FDJ:Emit("FDJ_WISHES")
    FDJ:Emit("FDJ_BIS_OPTIONS", key)
end

function Bis.Has(itemID, charKey)
    if not Bis.On() then return false end
    return Bis.Find(itemID, charKey) ~= nil
end

function Bis.ForTooltip(itemID)
    if not (Bis.On() and Bis.Options().tooltip) then return nil end
    return Bis.Find(itemID)
end

function Bis.AlertFor(itemID)
    return Bis.On() and Bis.Options().alerts and Bis.Find(itemID) ~= nil
end

function Bis.Takes(itemID)
    return Bis.On() and Bis.GroupFor(itemID) ~= nil
end

local function changed()
    FDJ:Emit("FDJ_WISHES")
end

function Bis.Add(itemID, charKey, quiet)
    local g = Bis.GroupFor(itemID)
    if not g then
        if not quiet then FDJ.Print(L.BIS_NOT_GEAR) end
        return false
    end
    if Bis.Has(itemID, charKey) then return true end
    local s = store(charKey)
    s[g.key] = s[g.key] or {}
    table.insert(s[g.key], itemID)
    if not quiet then
        local _, link = C_Item.GetItemInfo(itemID)
        FDJ.Print(L.BIS_ADDED:format(link or ("item " .. itemID), Bis.Label(g)))
    end
    changed()
    return true
end

function Bis.Remove(itemID, charKey)
    local g, rank = Bis.Find(itemID, charKey)
    if not g then return end
    table.remove(store(charKey)[g.key], rank)
    changed()
end

function Bis.ClearSlot(group, index, charKey)
    local list = store(charKey)[group.key]
    if not list then return end
    index = index or 1
    local wants = Bis.Wants(group)
    for i = #list, 1, -1 do
        if i == index or i > wants then table.remove(list, i) end
    end
    changed()
end

function Bis.Toggle(itemID, charKey)
    if Bis.Has(itemID, charKey) then Bis.Remove(itemID, charKey) else Bis.Add(itemID, charKey) end
end

function Bis.Promote(itemID, charKey)
    local g, rank = Bis.Find(itemID, charKey)
    if not g or rank == 1 then return end
    local list = store(charKey)[g.key]
    table.remove(list, rank)
    table.insert(list, 1, itemID)
    changed()
end

function Bis.Picks(group, charKey)
    return store(charKey)[group.key] or {}
end

local function owned(itemID)
    if C_Item.GetItemCount and C_Item.GetItemCount(itemID, true) > 0 then return true end
    if GetItemCount and GetItemCount(itemID, true) > 0 then return true end
    return false
end

local stateCache = {}
function Bis.State(group, itemID)
    for _, slot in ipairs(group.slots) do
        if GetInventoryItemID("player", slot) == itemID then return "equipped" end
    end
    local hit = stateCache[itemID]
    if hit == nil then
        local ok, have = pcall(owned, itemID)
        hit = (ok and have) and true or false
        stateCache[itemID] = hit
    end
    return hit and "owned" or "missing"
end
FDJ:On("BAG_UPDATE_DELAYED", function() wipe(stateCache) end)
FDJ:On("PLAYER_EQUIPMENT_CHANGED", function() wipe(stateCache) end)
FDJ:On("PLAYERBANKSLOTS_CHANGED", function() wipe(stateCache) end)

function Bis.Done(group)
    local picks = Bis.Picks(group)
    if #picks == 0 then return nil end
    for i = 1, math.min(Bis.Wants(group), #picks) do
        if Bis.State(group, picks[i]) ~= "equipped" then return false end
    end
    return true
end

function Bis.Progress()
    local done, total = 0, 0
    for _, g in ipairs(Bis.GROUPS) do
        local d = Bis.Done(g)
        if d ~= nil then
            total = total + 1
            if d then done = done + 1 end
        end
    end
    return done, total
end

function Bis.Source(itemID)
    local src = FDJ.LootSources[itemID] and FDJ.LootSources[itemID][1]
    return src and src.boss, src and src.odds
end

local questRewards
function Bis.QuestFor(itemID)
    if not questRewards then
        questRewards = {}
        local side = UnitFactionGroup("player")
        for qid, q in pairs(FDJ.QuestBook or {}) do
            if not q.side or q.side == side then
                for _, id in ipairs(q.gives or {}) do
                    if not questRewards[id] then questRewards[id] = qid end
                end
            end
        end
    end
    local qid = questRewards[itemID]
    return qid and FDJ.QuestBook[qid], qid
end

function Bis.QuestRewards()
    Bis.QuestFor(0)
    return questRewards
end

function Bis.RunNext()
    local count, items = {}, {}
    for _, g in ipairs(Bis.GROUPS) do
        local picks = Bis.Picks(g)
        for i = 1, math.min(Bis.Wants(g), #picks) do
            local id = picks[i]
            if Bis.State(g, id) == "missing" then
                local boss = Bis.Source(id)
                if boss then
                    local d = boss.dungeon
                    count[d] = (count[d] or 0) + 1
                    items[d] = items[d] or {}
                    table.insert(items[d], id)
                end
            end
        end
    end

    local level = FDJ.Level()
    local function reach(d) return (d.range and d.range[1] or 0) <= level + 2 end
    local best
    for d, n in pairs(count) do
        if not best then
            best = d
        else
            local a, b = reach(d), reach(best)
            if a ~= b then
                if a then best = d end
            elseif n > count[best] or (n == count[best] and (d.range[1] or 0) < (best.range[1] or 0)) then
                best = d
            end
        end
    end
    return best, best and count[best] or 0, best and items[best], best and not reach(best)
end

function Bis.Export(charKey)
    local parts = {}
    for _, g in ipairs(Bis.GROUPS) do
        local picks = Bis.Picks(g, charKey)
        if #picks > 0 then
            local ids = {}
            for i, id in ipairs(picks) do ids[i] = tostring(id) end
            parts[#parts + 1] = g.key .. "=" .. table.concat(ids, ",")
        end
    end
    local name = (Bis.ActiveName(charKey) or ""):gsub("[;=]", "")
    if name ~= "" then parts[#parts + 1] = "name=" .. name:gsub(" ", "_") end
    return "FCBIS1:" .. table.concat(parts, ";")
end

function Bis.Import(text)
    text = (text or ""):gsub("%s", "")
    local body = text:match("^FCBIS1:(.*)$")
    if not body then
        FDJ.Print(L.BIS_IMPORT_BAD)
        return false
    end
    local incoming, n = {}, 0
    local name = body:match("name=([^;]+)")
    name = name and name:gsub("_", " ") or L.BIS_IMPORTED_NAME
    for key, ids in body:gmatch("(%a+)=([%d,]+)") do
        if BY_KEY[key] then
            incoming[key] = {}
            for id in ids:gmatch("%d+") do
                table.insert(incoming[key], tonumber(id))
                n = n + 1
            end
        end
    end
    if n == 0 then
        FDJ.Print(L.BIS_IMPORT_BAD)
        return false
    end

    local final = Bis.FreeName(name)
    Bis.NewList(final, false)
    local s = store()
    for key, list in pairs(incoming) do s[key] = list end
    FDJ.Print(L.BIS_IMPORTED:format(n, final))
    changed()
    return true
end

function Bis.AdoptLists(fromKey)
    local src = FDJ.db and FDJ.db.chars[fromKey]
    if not src or fromKey == FDJ.charKey then return end
    local all = lists()
    local mySpecs = {}
    for _, sp in ipairs(Bis.Specs()) do mySpecs[sp.key] = true end
    local cur = specOf()
    local moved = 0
    for _, l in ipairs(type(src.bisLists) == "table" and src.bisLists or {}) do
        if not mySpecs[l.spec or ""] then l.spec = cur end
        all[#all + 1] = l
        moved = moved + 1
    end
    if moved == 0 and type(src.bis) == "table" then
        all[#all + 1] = { name = L.BIS_LIST_DEFAULT, spec = cur, picks = src.bis }
        moved = 1
    end
    src.bisLists, src.bis, src.bisActive, src.bisSpec, src.bisBySpec = nil, nil, nil, nil, nil
    if not fromKey:match("%-%x%x%x%x%x%x+$") then FDJ.db.chars[fromKey] = nil end
    if moved > 0 then FDJ.Print(L.BIS_ADOPTED:format(moved)) end
    changedLists()
end

function Bis.Characters()
    local list = {}
    for key, data in pairs(FDJ.db.chars) do
        if type(data) == "table" and (type(data.bisLists) == "table" or type(data.bis) == "table" or key == FDJ.charKey) then
            local n = 0
            if type(data.bisLists) == "table" then
                for _, l in ipairs(data.bisLists) do
                    for _, picks in pairs(l.picks or {}) do n = n + #picks end
                end
            elseif type(data.bis) == "table" then
                for _, picks in pairs(data.bis) do n = n + #picks end
            end
            if n > 0 or key == FDJ.charKey then
                local old = not key:match("%-%x%x%x%x%x%x+$")
                list[#list + 1] = { key = key, class = data.class, n = n, old = old,
                    name = data.name or key:match("^([^%-]+)") or key, me = key == FDJ.charKey }
            end
        end
    end
    table.sort(list, function(a, b)
        if a.me ~= b.me then return a.me end
        return a.name < b.name
    end)
    return list
end

local function hookClicks()
    if Bis.hooked or not HandleModifiedItemClick then return end
    Bis.hooked = true
    hooksecurefunc("HandleModifiedItemClick", function(link)
        if not (IsAltKeyDown() and IsShiftKeyDown()) or not Bis.On() or not Bis.Options().altClick then return end
        local id = FDJ.ItemFromLink(link)
        if id and Bis.GroupFor(id) then Bis.Toggle(id) end
    end)
end

local function migrate()
    local char = FDJ.char
    if not char or char.bisMigrated then return end
    char.bisMigrated = true
    for itemID in pairs(char.wishes or {}) do
        if Bis.GroupFor(itemID) and Bis.Add(itemID, nil, true) then char.wishes[itemID] = nil end
    end
end

local keyButton = CreateFrame("Button", "FojjiCoreBisKey", UIParent)
keyButton:SetScript("OnClick", function()
    if Bis.On() and Bis.TogglePopout then Bis.TogglePopout() end
end)
local keyPending = false
function Bis.ApplyKey()
    if InCombatLockdown and InCombatLockdown() then keyPending = true return end
    keyPending = false
    ClearOverrideBindings(keyButton)
    local key = Bis.On() and Bis.Options().key
    if key and key ~= "" then SetOverrideBindingClick(keyButton, false, key, "FojjiCoreBisKey") end
end
FDJ:On("PLAYER_REGEN_ENABLED", function() if keyPending then Bis.ApplyKey() end end)

FDJ:On("PLAYER_LOGIN", function()
    hookClicks()
    pcall(migrate)
    Bis.ApplyKey()
end)
FDJ:On("PLAYER_EQUIPMENT_CHANGED", function() FDJ.Debounce("bisgear", 0.3, changed) end)

local function listIsEmpty()
    for _, picks in pairs(store()) do
        if #picks > 0 then return false end
    end
    return true
end
FDJ:On("PLAYER_LEVEL_UP", function()
    if Bis.On() and Bis.Options().autoSuggest and Bis.Suggest and listIsEmpty() then
        C_Timer.After(2, function()
            if listIsEmpty() then Bis.Suggest.Fill(false) end
        end)
    end
end)
