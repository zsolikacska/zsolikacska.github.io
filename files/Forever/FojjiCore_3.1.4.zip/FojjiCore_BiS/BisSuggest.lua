local Addon = FojjiCoreNS
if not Addon then return end
local FDJ = Addon.DJ

local L = FDJ.L
local Bis = FDJ.Bis

local Suggest = {}
Bis.Suggest = Suggest

local ARMOR = { cloth = 1, leather = 2, mail = 3, plate = 4 }
local CLASS_ARMOR = {
    MAGE = { 1 }, PRIEST = { 1 }, WARLOCK = { 1 },
    ROGUE = { 2 }, DRUID = { 2 },
    HUNTER = { 2, 40, 3 }, SHAMAN = { 2, 40, 3 },
    WARRIOR = { 3, 40, 4 }, PALADIN = { 3, 40, 4 },
}

local WEAPONS = {
    WARRIOR = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 13, 15, 16, 18 },
    PALADIN = { 0, 1, 4, 5, 6, 7, 8 },
    HUNTER = { 0, 1, 2, 3, 6, 7, 8, 10, 13, 15, 16, 18 },
    ROGUE = { 2, 3, 4, 7, 13, 15, 16, 18 },
    PRIEST = { 4, 10, 15, 19 },
    SHAMAN = { 0, 1, 4, 5, 10, 13, 15 },
    MAGE = { 7, 10, 15, 19 },
    WARLOCK = { 7, 10, 15, 19 },
    DRUID = { 4, 5, 10, 13, 15 },
}

local OFFHAND_ARMOR = { WARRIOR = { 6 }, PALADIN = { 6, 7 }, SHAMAN = { 6, 9 }, DRUID = { 8 } }

local canWield = {}
for class, list in pairs(WEAPONS) do
    canWield[class] = {}
    for _, sub in ipairs(list) do canWield[class][sub] = true end
end

local function class()
    local _, c = UnitClass("player")
    return c
end

local function maxArmor(c, level)
    local rule = CLASS_ARMOR[c] or { 1 }
    if rule[2] and level >= rule[2] then return rule[3] end
    return rule[1]
end

function Suggest.Usable(itemID, c, level)
    c = c or class()
    level = level or FDJ.Level()
    local _, _, _, loc, _, classID, subID = C_Item.GetItemInfoInstant(itemID)
    if not loc or loc == "" then return false end
    if classID == 2 then
        return canWield[c] and canWield[c][subID] or false
    end
    if classID == 4 then
        if loc == "INVTYPE_CLOAK" or loc == "INVTYPE_NECK" or loc == "INVTYPE_FINGER" or loc == "INVTYPE_TRINKET" or loc == "INVTYPE_HOLDABLE" then
            return true
        end
        if subID == 0 then return true end
        if subID >= 6 then
            for _, s in ipairs(OFFHAND_ARMOR[c] or {}) do if s == subID then return true end end
            return false
        end
        return subID <= maxArmor(c, level)
    end
    return false
end

local BODY_ARMOR = {
    INVTYPE_HEAD = true, INVTYPE_SHOULDER = true, INVTYPE_CHEST = true, INVTYPE_ROBE = true, INVTYPE_WRIST = true,
    INVTYPE_HAND = true, INVTYPE_WAIST = true, INVTYPE_LEGS = true, INVTYPE_FEET = true,
}
local PRIMARY = { STR = true, AGI = true, INT = true, SPI = true, AP = true, SP = true, HEAL = true }

local blocked = {}
local LEVEL_LINE = ITEM_MIN_LEVEL and ("^" .. ITEM_MIN_LEVEL:gsub("%%d", "%%d+") .. "$")
local function redLine(itemID)
    if blocked[itemID] ~= nil then return blocked[itemID] end
    if not (C_TooltipInfo and C_TooltipInfo.GetItemByID) then return false end
    local ok, data = pcall(C_TooltipInfo.GetItemByID, itemID)
    if not ok or type(data) ~= "table" or not data.lines then return false end
    local red = false
    for i, line in ipairs(data.lines) do
        local c = line.leftColor
        local text = line.leftText
        if i > 1 and c and text and c.r and c.r > 0.9 and c.g < 0.2 and c.b < 0.2 then
            if not (LEVEL_LINE and text:match(LEVEL_LINE)) then red = true break end
        end
        c = line.rightColor
        text = line.rightText
        if c and text and c.r and c.r > 0.9 and c.g < 0.2 and c.b < 0.2 then red = true break end
    end
    blocked[itemID] = red
    return red
end
Suggest.Blocked = redLine

local function reachable(itemID, req)
    local at = req or 0
    local boss = Bis.Source(itemID)

    local low
    for _, src in ipairs(FDJ.LootSources[itemID] or {}) do
        local d = src.boss and src.boss.dungeon
        if d and d.range and (not low or d.range[1] < low) then low = d.range[1] end
    end
    if low then at = math.max(at, low) end
    if not boss then
        local q = Bis.QuestFor(itemID)
        if q then at = math.max(at, q.req or q.lv or 0) end
    end
    return at
end
Suggest.Reachable = reachable

local function dpsFactor(groupKey, c, weights)
    if groupKey == "mainhand" then return 1 end
    if groupKey == "ranged" then return c == "HUNTER" and 1 or 0 end
    if groupKey == "offhand" then return (weights.DPS or 0) >= 5 and 0.5 or 0 end
    return 1
end

function Suggest.Score(itemID, weights, c, level, groupKey)
    local name, link, _, ilvl, req = C_Item.GetItemInfo(itemID)
    if not name then return nil end
    c = c or class()
    level = level or FDJ.Level()
    weights = weights or Bis.Stats.Weights(c)
    local item = Bis.Stats.Item(itemID)
    if not item then return nil end
    local score = (ilvl or 0) * 0.05 + Bis.Stats.Score(item.stats, weights)
    if item.stats.DPS and weights.DPS then
        score = score - item.stats.DPS * weights.DPS * (1 - dpsFactor(groupKey, c, weights))
    end
    local useful, wrong = 0, 0
    for k in pairs(item.stats) do
        if PRIMARY[k] then
            if (weights[k] or 0) > 0.2 then useful = useful + 1 else wrong = wrong + 1 end
        end
    end

    if c == class() and level <= FDJ.Level() and redLine(itemID) then return false end

    if wrong > 0 and useful == 0 then return false end

    local _, _, _, loc, _, classID, subID = C_Item.GetItemInfoInstant(itemID)
    if classID == 4 and BODY_ARMOR[loc] and subID and subID >= 1 and subID <= 4 then
        local best = maxArmor(c, math.max(level, req or 0))
        score = score - (best - subID) * math.max(4, score * 0.25)
    end
    return score, ilvl or 0, reachable(itemID, req)
end

local pending, failed = {}, {}

local function want(itemID)
    if C_Item.GetItemInfo(itemID) then return true end
    if failed[itemID] then return nil end
    local asked = pending[itemID]
    if not asked then
        pending[itemID] = GetTime()
        C_Item.RequestLoadItemDataByID(itemID)
        return false
    end
    if GetTime() - asked > 8 then
        pending[itemID] = nil
        failed[itemID] = true
        return nil
    end
    return false
end

local pools = {}
function Suggest.Pool(group, c, level)
    local cacheKey = tostring(c) .. ":" .. tostring(level) .. ":" .. group.key
    if pools[cacheKey] then return pools[cacheKey] end
    local out = {}
    local seen = {}
    local function consider(itemID)
        if seen[itemID] then return end
        seen[itemID] = true
        local g = Bis.GroupFor(itemID)
        if g == group and Suggest.Usable(itemID, c, level) then out[#out + 1] = itemID end
    end
    for itemID in pairs(FDJ.LootSources) do consider(itemID) end
    for itemID in pairs(Bis.QuestRewards()) do consider(itemID) end
    pools[cacheKey] = out
    return out
end

function Suggest.Ranked(group, opts)
    opts = opts or {}
    local c, level = opts.class or class(), opts.level or FDJ.Level()
    local reach = opts.reach or 0
    local weights = opts.weights or Bis.Stats.Weights(c, opts.spec)
    local list, ahead, waiting = {}, {}, 0
    for _, itemID in ipairs(Suggest.Pool(group, c, level)) do
        local ready = want(itemID)
        if ready then
            local score, ilvl, req = Suggest.Score(itemID, weights, c, level, group.key)
            if score then
                local e = { id = itemID, score = score, ilvl = ilvl, req = req }
                if opts.any or req <= level + reach then
                    list[#list + 1] = e
                else
                    ahead[#ahead + 1] = e
                end
            end
        elseif ready == false then
            waiting = waiting + 1
        end
    end
    table.sort(list, function(a, b)
        if a.score ~= b.score then return a.score > b.score end
        return a.id < b.id
    end)

    local nextLevel
    if #list == 0 and not opts.any then
        for _, e in ipairs(ahead) do
            if not nextLevel or e.req < nextLevel then nextLevel = e.req end
        end
    end
    return list, waiting, nextLevel
end

function Suggest.Loading()
    local n = 0
    for id in pairs(pending) do
        if C_Item.GetItemInfo(id) then pending[id] = nil else n = n + 1 end
    end
    return n
end

Suggest.PRESETS = {
    { key = "lv20", level = 20 },
    { key = "lv30", level = 30 },
    { key = "lv40", level = 40 },
    { key = "lv50", level = 50 },
    { key = "preraid", level = 60 },
    { key = "phase1", level = 60, raid = true },
}

function Suggest.PresetName(p)
    if p.key == "preraid" then return L.BIS_PRESET_PRERAID end
    if p.key == "phase1" then return L.BIS_PRESET_PHASE1 end
    return L.BIS_PRESET_LEVEL:format(p.level)
end

function Suggest.HasRaidLoot()
    for _, d in ipairs(FDJ.Dungeons or {}) do
        if d.raid then return true end
    end
    return false
end

function Suggest.Fill(replace, done, opts)
    opts = opts or {}
    local level = opts.level or FDJ.Level()
    local tries = 0
    local function run()
        local waiting, results = 0, {}
        for _, g in ipairs(Bis.GROUPS) do
            if not g.optional then
                local list, w = Suggest.Ranked(g, { level = level })
                waiting = waiting + w
                results[g] = list
            end
        end
        tries = tries + 1
        if waiting > 0 and tries < 20 then
            if done then done(false, waiting) end
            C_Timer.After(0.5, run)
            return
        end
        if opts.list then
            Bis.NewList(Bis.FreeName(opts.list), false)
            replace = true
        end

        local mhGroup, ohGroup
        for g in pairs(results) do
            if g.key == "mainhand" then mhGroup = g elseif g.key == "offhand" then ohGroup = g end
        end
        if mhGroup and ohGroup then
            local best2H, best1H
            for _, e in ipairs(results[mhGroup]) do
                local _, _, _, loc = C_Item.GetItemInfoInstant(e.id)
                if loc == "INVTYPE_2HWEAPON" then best2H = best2H or e else best1H = best1H or e end
                if best2H and best1H then break end
            end
            local oh = results[ohGroup][1]
            local pair = (best1H and best1H.score or 0) + (oh and oh.score or 0)
            if best2H and best2H.score >= pair then
                results[mhGroup] = { best2H }
                results[ohGroup] = {}
            elseif best1H then
                results[mhGroup] = { best1H }
            end
        end
        local s = Bis.Store()
        local filled = 0
        for g, list in pairs(results) do
            if replace or not s[g.key] or #s[g.key] == 0 then
                local picks = {}
                for i = 1, math.min(#list, Bis.Wants(g)) do picks[i] = list[i].id end
                s[g.key] = picks
                if #picks > 0 then filled = filled + 1 end
            end
        end
        FDJ.Print(L.BIS_SUGGESTED:format(filled, level))
        FDJ:Emit("FDJ_WISHES")
        if done then done(true, 0) end
    end
    run()
end

local arrived = {}
FDJ:On("GET_ITEM_INFO_RECEIVED", function(itemID, success)
    if not pending[itemID] then return end
    pending[itemID] = nil
    if success == false then failed[itemID] = true end
    local g = Bis.GroupFor(itemID)
    if g then arrived[g.key] = true end
    local busy = Suggest.Loading() > 20
    FDJ.Debounce("bisitems", busy and 1.2 or 0.3, function()
        local keys = arrived
        arrived = {}
        FDJ:Emit("FDJ_BIS_ITEMS", keys)
    end)
end)
FDJ:On("SKILL_LINES_CHANGED", function() wipe(blocked) end)
FDJ:On("PLAYER_LEVEL_UP", function() wipe(blocked) end)
