local Addon = FojjiCoreNS
if not Addon then return end
local FDJ = Addon.DJ

local Kit = FDJ.Kit
local C = FDJ.Colors
local L = FDJ.L
local RGB = Kit.RGB
local Bis = FDJ.Bis

local HERO_W = 340
local SLOT = 36
local SLOT_GAP = 5
local LEFT_SLOTS = { 1, 2, 3, 15, 5, 19, 9 }
local RIGHT_SLOTS = { 10, 6, 7, 8, 11, 12, 13, 14 }
local BOTTOM_SLOTS = { 16, 17, 18 }
local ROW_H = 54
local TILE = 38
local CORE = "Interface\\AddOns\\FojjiCore\\textures\\UI\\"

local SLOT_NAMES = {
    [1] = "HeadSlot", [2] = "NeckSlot", [3] = "ShoulderSlot", [15] = "BackSlot", [5] = "ChestSlot",
    [9] = "WristSlot", [10] = "HandsSlot", [6] = "WaistSlot", [7] = "LegsSlot", [8] = "FeetSlot",
    [11] = "Finger0Slot", [12] = "Finger1Slot", [13] = "Trinket0Slot", [14] = "Trinket1Slot",
    [16] = "MainHandSlot", [17] = "SecondaryHandSlot", [18] = "RangedSlot", [19] = "TabardSlot",
}
local HAND = { [16] = "MAINHANDSLOT", [17] = "SECONDARYHANDSLOT" }
local SLOT_LABEL = { [11] = L.BIS_RING1, [12] = L.BIS_RING2, [13] = L.BIS_TRINKET1, [14] = L.BIS_TRINKET2 }

local STATUS = {
    worn = { color = "good", key = "BIS_STATUS_WORN" },
    bags = { color = "amber", key = "BIS_STATUS_BAGS" },
    missing = { color = "muted", key = "BIS_STATUS_MISSING" },
    empty = { color = "dim", key = "BIS_STATUS_EMPTY" },
}

local function groupOfSlot(slot)
    for _, g in ipairs(Bis.GROUPS) do
        for i, s in ipairs(g.slots) do
            if s == slot then return g, i end
        end
    end
end

local asked = {}
local function quality(itemID)
    local name, _, q = C_Item.GetItemInfo(itemID)
    if not name and not asked[itemID] then
        asked[itemID] = true
        C_Item.RequestLoadItemDataByID(itemID)
    end
    local qc = q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
    return name, qc and { qc.r, qc.g, qc.b } or nil
end

local function slotTexture(slot)
    local name = SLOT_NAMES[slot]
    if name and GetInventorySlotInfo then
        local ok, _, tex = pcall(GetInventorySlotInfo, name)
        if ok and tex then return tex end
    end
    return 134400
end

local function sourceText(itemID)
    local boss, odds = Bis.Source(itemID)
    if not boss then
        local q = Bis.QuestFor(itemID)
        if not q then return nil end
        return L.BIS_FROM_QUEST:format(q.t) .. ((q.at and q.at ~= "") and FDJ.Paint("dim", "  ·  " .. q.at) or "")
    end
    return FDJ.DungeonTitle(boss.dungeon) .. FDJ.Paint("dim", "  ·  ") .. boss.n
        .. (odds and FDJ.Paint("dim", "  " .. odds .. "%") or "")
end

local function gainText(a, b)
    a, b = a or 0, b or 0
    if b <= 0 then return "", nil end
    if a <= 0 then return L.BIS_NEW, "good" end
    local d = b - a
    if math.abs(d) < 0.005 * math.max(a, 1) then return "", nil end
    if a < b * 0.25 then return ("%+d"):format(math.floor(d + 0.5)), "good" end
    local pct = math.floor(d / a * 100 + (d > 0 and 0.5 or -0.5))
    pct = math.max(-99, math.min(999, pct))
    return ("%+d%%"):format(pct), d > 0 and "good" or "bad"
end

local function backable(f, title)
    f.back = Kit.Button(f, L.BIS_BACK, nil, 24, function() f:Hide() end, nil, "fc:icon-chevron-right")
    if f.back.glyph then f.back.glyph:SetTexCoord(1, 0, 0, 1) end
    f.back:SetPoint("TOPLEFT", 10, -10)
    f.back:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    title:ClearAllPoints()
    title:SetPoint("LEFT", f.back, "RIGHT", 12, 0)
    f:SetScript("OnMouseUp", function(self, button) if button == "RightButton" then self:Hide() end end)
end

local function openBoss(itemID)
    local boss = Bis.Source(itemID)
    if boss and FDJ.Journal and FDJ.Journal.Open then FDJ.Journal.Open(boss.dungeon, "overview", boss) end
end

local function groupStatus(g, mine, key)
    local picks = Bis.Picks(g, key)
    if #picks == 0 then return "empty" end
    if not mine then return "missing" end
    local worst = "worn"
    for i = 1, math.min(Bis.Wants(g), #picks) do
        local st = Bis.State(g, picks[i])
        if st == "missing" then return "missing" end
        if st == "owned" then worst = "bags" end
    end
    return worst
end

local function card(parent)
    local f = CreateFrame("Frame", nil, parent)
    Kit.Fill(f, C.panel, 0.72)
    Kit.Edge(f, C.borderDim)
    local top = f:CreateTexture(nil, "ARTWORK")
    top:SetPoint("TOPLEFT", 1, -1)
    top:SetPoint("TOPRIGHT", -1, -1)
    top:SetHeight(1)
    Kit.Paint(top, C.accent, 0.55)
    return f
end

local function tipItem(owner, itemID, extra, compare)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetItemByID(itemID)
    if compare and GameTooltip_ShowCompareItem then pcall(GameTooltip_ShowCompareItem, GameTooltip) end
    local where = sourceText(itemID)
    if where then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(where, C.text[1], C.text[2], C.text[3])
    end
    if extra then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(extra, 0.6, 0.6, 0.65, true)
    end
    GameTooltip:Show()
end

local function dungeonArt(tex, d)
    local screen = FDJ.LoadScreens and FDJ.LoadScreens[d.key]
    if screen then
        tex:SetTexture(screen, nil, nil, "TRILINEAR")
        local id = tex.GetTextureFileID and tex:GetTextureFileID()
        if id and id ~= 0 then
            tex:SetTexCoord(0.05, 0.95, 0.36, 0.64)
            return true
        end
    end
    if d.art then
        tex:SetTexture(d.art[2], nil, nil, "TRILINEAR")
        tex:SetTexCoord(0, 0.70, 0.22, 0.46)
        return true
    end
    local cover = FDJ.Journal and FDJ.Journal.CoverFor and FDJ.Journal.CoverFor(d)
    if cover then
        tex:SetTexture(cover, nil, nil, "TRILINEAR")
        tex:SetTexCoord(0, 1, 0.38, 0.62)
        return true
    end
    return false
end

local function pill(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetHeight(18)
    p.bg = p:CreateTexture(nil, "BACKGROUND")
    p.bg:SetAllPoints()
    p.dot = p:CreateTexture(nil, "ARTWORK")
    p.dot:SetSize(6, 6)
    p.dot:SetPoint("LEFT", 7, 0)
    p.text = Kit.Text(p, "tiny", C.text)
    p.text:SetPoint("LEFT", p.dot, "RIGHT", 5, 0)
    function p:Set(text, color)
        self.text:SetText(text)
        self.text:SetTextColor(RGB(color))
        self.dot:SetColorTexture(RGB(color))
        self.bg:SetColorTexture(RGB(color, 0.13))
        self:SetWidth(self.text:GetUnboundedStringWidth() + 24)
    end
    return p
end

local buildSettings

local function buildManager(page, top, pad)
    FDJ.SyncTheme()
    pad = pad or 0
    local outer = CreateFrame("Frame", nil, page)
    outer:SetPoint("TOPLEFT", pad, top)
    outer:SetPoint("BOTTOMRIGHT", -pad, pad)
    local tabs, settings
    local view = CreateFrame("Frame", nil, outer)
    view:SetPoint("TOPLEFT", 0, -40)
    view:SetPoint("BOTTOMRIGHT")
    local off = CreateFrame("Frame", nil, outer)
    off:SetPoint("TOPLEFT", 0, -40)
    off:SetPoint("BOTTOMRIGHT")
    off.text = Kit.Text(off, "normal", C.muted, "CENTER")
    off.text:SetPoint("CENTER", 0, 20)
    off.text:SetText(L.BIS_OFF)
    off.on = Kit.Button(off, L.BIS_TURN_ON, nil, 28, function() Bis.Set("enabled", true) end, "primary")
    off.on:SetPoint("TOP", off.text, "BOTTOM", 0, -12)
    settings = buildSettings(outer)
    settings:SetPoint("TOPLEFT", 0, -40)
    settings:SetPoint("BOTTOMRIGHT")
    local function showTab(key)
        local on = Bis.On()
        view:SetShown(key == "list" and on)
        off:SetShown(key == "list" and not on)
        settings:SetShown(key == "settings")
    end
    tabs = Kit.Tabs(outer, { { "list", L.BIS_TAB_LIST }, { "settings", L.BIS_TAB_SETTINGS } }, showTab)
    tabs.first:SetPoint("TOPLEFT", -6, 0)
    local rule = outer:CreateTexture(nil, "BORDER")
    rule:SetPoint("TOPLEFT", 0, -33)
    rule:SetPoint("TOPRIGHT", 0, -33)
    rule:SetHeight(1)
    Kit.Paint(rule, C.borderDim)
    outer:SetScript("OnShow", function() showTab(tabs.current or "list") end)
    FDJ:On("FDJ_BIS_OPTIONS", function() if outer:IsVisible() then showTab(tabs.current or "list") end end)
    tabs:Select("list")

    local state = { viewKey = nil, look = "bis" }
    local later
    local rowsByGroup = {}
    local function mine() return state.viewKey == nil or state.viewKey == FDJ.charKey end

    local bar = CreateFrame("Frame", nil, view)
    bar:SetPoint("TOPLEFT")
    bar:SetPoint("TOPRIGHT")
    bar:SetHeight(30)

    local listBtn = Kit.Button(bar, "", 220, 28)
    listBtn:SetPoint("LEFT")
    listBtn.label:ClearAllPoints()
    listBtn.label:SetPoint("LEFT", 10, 0)
    listBtn.label:SetPoint("RIGHT", -24, 0)
    listBtn.label:SetJustifyH("LEFT")
    local caret = Kit.Glyph(listBtn, "fc:icon-chevron-down", 12, C.muted)
    caret:SetPoint("RIGHT", -9, 0)

    local function otherChars()
        local others = {}
        for _, w in ipairs(Bis.Characters()) do
            if not w.me and w.n > 0 then others[#others + 1] = w end
        end
        return others
    end
    listBtn:SetScript("OnClick", function(self)
        local others = otherChars()
        if #others == 0 then return end
        local items = { { text = L.BIS_CHARACTERS, title = true } }
        local meName = FDJ.char and FDJ.char.name or "?"
        items[#items + 1] = { text = FDJ.Paint(FDJ.Party.ClassColor(FDJ.char and FDJ.char.class), meName) .. FDJ.Paint("dim", "  " .. L.BIS_THIS_CHAR),
            checked = mine(),
            onClick = function()
                state.viewKey = nil
                page:Refresh()
            end }
        do
            for _, w in ipairs(others) do
                if w.old then
                    items[#items + 1] = {
                        text = FDJ.Paint("muted", w.name) .. FDJ.Paint("dim", "  " .. L.BIS_OLD_SAVE .. "  " .. L.ITEMS_N:format(w.n)),
                        checked = state.viewKey == w.key,
                        onClick = function()
                            state.viewKey = w.key
                            page:Refresh()
                        end,
                        deleteTip = L.BIS_OLD_DELETE,
                        onDelete = function()
                            Kit.Confirm(L.BIS_OLD_DELETE_Q, function()
                                if state.viewKey == w.key then state.viewKey = nil end
                                Bis.DeleteSave(w.key)
                            end)
                        end }
                    items[#items + 1] = { text = "      " .. FDJ.Paint("accent", L.BIS_ADOPT), onClick = function()
                        Kit.Confirm(L.BIS_ADOPT_Q:format(w.n), function()
                            state.viewKey = nil
                            Bis.AdoptLists(w.key)
                        end)
                    end }
                else
                items[#items + 1] = {
                    text = FDJ.Paint(FDJ.Party.ClassColor(w.class), w.name) .. FDJ.Paint("dim", "  " .. (Bis.ActiveName(w.key)) .. "  " .. L.ITEMS_N:format(w.n)),
                    checked = state.viewKey == w.key,
                    onClick = function()
                        state.viewKey = w.key
                        page:Refresh()
                    end }
                end
            end
        end
        Kit.Menu(self, items, self:GetWidth())
    end)

    local function nameList(title, default, done)
        Kit.Prompt(title, default or "", function(text)
            text = (text or ""):gsub("^%s+", ""):gsub("%s+$", "")
            if text ~= "" then done(text) end
        end)
    end
    local popout = Kit.IconButton(bar, "fc:icon-export", 28, L.BIS_POPOUT, function()
        if page.isPopout then page:Hide() else Bis.TogglePopout() end
    end)
    popout:SetPoint("RIGHT")
    popout:SetShown(not page.isPopout)
    local import = Kit.Button(bar, L.IMPORT, nil, 28, function()
        Kit.TextWindow(L.BIS_IMPORT_TITLE, "", function(text)
            state.viewKey = nil
            return Bis.Import(text)
        end, L.BIS_IMPORT_HINT)
    end)
    if page.isPopout then import:SetPoint("RIGHT") else import:SetPoint("RIGHT", popout, "LEFT", -6, 0) end
    local export = Kit.Button(bar, L.EXPORT, nil, 28, function()
        Kit.TextWindow(L.BIS_EXPORT_TITLE, Bis.Export(state.viewKey), nil, L.BIS_EXPORT_HINT)
    end)
    export:SetPoint("RIGHT", import, "LEFT", -6, 0)
    local suggest = Kit.Button(bar, L.BIS_SUGGEST, nil, 28, nil, nil, "fc:icon-bis")
    suggest:SetPoint("RIGHT", export, "LEFT", -6, 0)
    local suggestCaret = Kit.Glyph(suggest, "fc:icon-chevron-down", 10, C.muted)
    suggestCaret:SetPoint("RIGHT", -9, 0)
    suggest.label:SetPoint("RIGHT", -24, 0)
    local baseLabel = suggest.SetLabel
    suggest.SetLabel = function(self, text)
        baseLabel(self, text)
        if self.autoWidth then self:SetWidth(self:GetWidth() + 14) end
    end
    suggest:SetLabel(L.BIS_SUGGEST)
    local busy = false
    local function runFill(replace, opts)
        if busy then return end
        busy = true
        state.viewKey = nil
        suggest:SetLabel(L.BIS_SUGGEST_LOADING)
        Bis.Suggest.Fill(replace, function(finished, waiting)
            suggest:SetLabel(finished and L.BIS_SUGGEST or L.BIS_SUGGEST_WAIT:format(waiting))
            if finished then busy = false end
        end, opts)
    end
    suggest:SetScript("OnClick", function(self)
        local items = { { text = L.BIS_PRESETS_HEAD, title = true } }
        local raid = Bis.Suggest.HasRaidLoot()
        for _, p in ipairs(Bis.Suggest.PRESETS) do
            local name = Bis.Suggest.PresetName(p)
            if p.raid and not raid then
                items[#items + 1] = { text = name .. FDJ.Paint("dim", "  " .. L.BIS_PRESET_SOON), disabled = true }
            else
                items[#items + 1] = { text = name, onClick = function()
                    runFill(true, { level = p.level, list = name })
                end }
            end
        end
        items[#items + 1] = { text = L.BIS_PRESET_CUSTOM, onClick = function()
            Kit.Prompt(L.BIS_PRESET_CUSTOM_Q, tostring(FDJ.Level()), function(text)
                local level = tonumber((text or ""):match("%d+"))
                if not level then return end
                level = math.max(1, math.min(60, math.floor(level)))
                runFill(true, { level = level, list = L.BIS_PRESET_LEVEL:format(level) })
            end)
        end }
        items[#items + 1] = { text = L.BIS_PRESET_EMPTY, onClick = function()
            nameList(L.BIS_LIST_NAME, Bis.FreeName(L.BIS_LIST_NEW), function(n) Bis.NewList(n, false) end)
        end }
        Kit.Menu(self, items, 250)
    end)

    local function tile(parent, size)
        local b = CreateFrame("Button", nil, parent)
        b:SetSize(size, size)
        b.bg = b:CreateTexture(nil, "BACKGROUND")
        b.bg:SetAllPoints()
        b.bg:SetColorTexture(0, 0, 0, 0.5)
        b.slot = b:CreateTexture(nil, "BORDER")
        b.slot:SetPoint("TOPLEFT", 2, -2)
        b.slot:SetPoint("BOTTOMRIGHT", -2, 2)
        b.slot:SetDesaturated(true)
        b.slot:SetAlpha(0.35)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetPoint("TOPLEFT", 2, -2)
        b.icon:SetPoint("BOTTOMRIGHT", -2, 2)
        b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        Kit.Edge(b, C.borderDim)
        b.check = b:CreateTexture(nil, "OVERLAY")
        b.check:SetSize(14, 14)
        b.check:SetPoint("BOTTOMRIGHT", 4, -4)
        b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        return b
    end

    local track = CreateFrame("Frame", nil, view)
    track:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", 0, -6)
    track:SetPoint("TOPRIGHT", bar, "BOTTOMRIGHT", 0, -6)
    track:SetHeight(32)
    Kit.Fill(track, C.panel, 0.6)
    Kit.Edge(track, C.borderDim, 0.7)
    track.line = track:CreateTexture(nil, "BORDER")
    track.line:SetHeight(2)
    track.line:SetPoint("LEFT", 14, 0)
    track.line:SetPoint("RIGHT", -14, 0)
    track.line:SetColorTexture(RGB(C.borderDim, 0.9))
    track.stops = {}
    track.slots = {}
    local dragging

    local function placeStops()
        local x = 10
        for i, b in ipairs(track.stops) do
            if b:IsShown() and b ~= dragging then
                b:ClearAllPoints()
                b:SetPoint("LEFT", x, 0)
                track.slots[i] = x
                x = x + b:GetWidth() + 14
            end
        end
        return x
    end

    local function trackStop(i)
        local b = track.stops[i]
        if b then return b end
        b = CreateFrame("Button", nil, track)
        b:SetHeight(24)
        b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        b:RegisterForDrag("LeftButton")
        b.bg = b:CreateTexture(nil, "BACKGROUND")
        b.bg:SetAllPoints()
        b.edge = Kit.Edge(b, C.borderDim)
        b.fill = b:CreateTexture(nil, "BORDER")
        b.fill:SetPoint("BOTTOMLEFT", 1, 1)
        b.fill:SetHeight(2)
        b.text = Kit.Text(b, "small", C.text)
        b.text:SetPoint("LEFT", 10, 0)
        b.count = Kit.Text(b, "tiny", C.muted)
        b.count:SetPoint("LEFT", b.text, "RIGHT", 6, 0)
        b:SetScript("OnEnter", function(self)
            if not self.on then Kit.EdgeColor(self, C.accent, 0.6) end
            if self.tip and not dragging then
                GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
                GameTooltip:SetText(self.tip, 1, 1, 1)
                if self.sub then GameTooltip:AddLine(self.sub, C.muted[1], C.muted[2], C.muted[3], true) end
                GameTooltip:Show()
            end
        end)
        b:SetScript("OnLeave", function(self)
            if not self.on then Kit.EdgeColor(self, C.borderDim) end
            Kit.HideTip()
        end)

        b:SetScript("OnDragStart", function(self)
            if not (mine() and self.listIndex) then return end
            dragging = self
            Kit.HideTip()
            self:SetFrameLevel(track:GetFrameLevel() + 10)
            self:SetAlpha(0.7)
            self.startX = select(1, GetCursorPosition()) / track:GetEffectiveScale() - self:GetLeft()
            self:SetScript("OnUpdate", function(me)
                local cx = GetCursorPosition() / track:GetEffectiveScale()
                me:ClearAllPoints()
                me:SetPoint("LEFT", track, "LEFT", math.max(4, cx - me.startX - track:GetLeft()), 0)
            end)
        end)
        b:SetScript("OnDragStop", function(self)
            if dragging ~= self then return end
            self:SetScript("OnUpdate", nil)
            self:SetAlpha(1)
            self:SetFrameLevel(track:GetFrameLevel() + 1)

            local centre = self:GetLeft() + self:GetWidth() / 2
            local target
            for _, other in ipairs(track.stops) do
                if other ~= self and other:IsShown() and other.listIndex and other:GetLeft() and centre > other:GetLeft() and centre < other:GetRight() then
                    target = other.listIndex
                end
            end
            dragging = nil
            if target and target ~= self.listIndex then
                Bis.MoveList(self.listIndex, target)
            else
                page:PaintTrack()
            end
        end)
        track.stops[i] = b
        return b
    end

    local addBtn = Kit.Button(track, L.BIS_TRACK_NEW, nil, 24, function(self)
        local open = suggest:GetScript("OnClick")
        if open then open(self) end
    end, nil, "fc:icon-plus")
    addBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:SetText(L.BIS_TRACK_ADD, 1, 1, 1)
        GameTooltip:AddLine(L.BIS_TRACK_ADD_TIP, C.muted[1], C.muted[2], C.muted[3], true)
        GameTooltip:Show()
    end)
    addBtn:SetScript("OnLeave", Kit.HideTip)

    function page:PaintTrack()
        if dragging then return end
        local lists = Bis.SpecLists(state.viewKey)
        local isMine = mine()
        for i, l in ipairs(lists) do
            local b = trackStop(i)
            local picked = 0
            for _, g in ipairs(Bis.GROUPS) do
                local p = l.picks and l.picks[g.key]
                if p and not g.optional then picked = picked + math.min(#p, Bis.Wants(g)) end
            end
            b.on = l.active
            b.listIndex = l.index
            b.tip, b.sub = l.name, isMine and L.BIS_TRACK_TIP or L.BIS_TRACK_TIP_ALT
            b.text:SetText(l.name)
            b.text:SetTextColor(RGB(b.on and C.white or C.text))
            local total = Bis.TotalSlots() - 1
            b.count:SetText(picked .. "/" .. total)
            b.bg:SetColorTexture(RGB(b.on and C.accent or C.frame, b.on and 0.30 or 0.95))
            Kit.EdgeColor(b, b.on and C.accent or C.borderDim, b.on and 0.9 or 1)
            local w = b.text:GetUnboundedStringWidth() + b.count:GetUnboundedStringWidth() + 26
            b:SetWidth(w)
            b.fill:SetWidth(math.max(1, (w - 2) * math.min(1, picked / total)))
            b.fill:SetColorTexture(RGB(C.accent, b.on and 1 or 0.6))
            b:SetScript("OnClick", function(self, button)
                if button == "RightButton" then
                    if not isMine then return end
                    Kit.Menu(self, {
                        { text = l.name, title = true },
                        { text = L.BIS_LIST_RENAME, onClick = function()
                            Bis.SetActive(l.index)
                            nameList(L.BIS_LIST_RENAME, l.name, function(n) Bis.RenameList(n) end)
                        end },
                        { text = L.BIS_LIST_COPY, onClick = function()
                            Bis.SetActive(l.index)
                            nameList(L.BIS_LIST_NAME, l.name .. " 2", function(n) Bis.NewList(n, true) end)
                        end },
                        { text = L.BIS_LIST_DELETE, onClick = function()
                            Kit.Confirm(L.BIS_LIST_DELETE_Q:format(l.name), function() Bis.DeleteListAt(l.index) end)
                        end },
                    }, 180)
                    return
                end
                Bis.SetActive(l.index, state.viewKey)
            end)
            b:Show()
        end
        for i = #lists + 1, #track.stops do track.stops[i]:Hide() end
        local x = placeStops()
        addBtn:ClearAllPoints()
        addBtn:SetPoint("LEFT", x, 0)
        addBtn:SetShown(isMine)
    end

    local hero = CreateFrame("Frame", nil, view)
    hero:SetPoint("TOPLEFT", track, "BOTTOMLEFT", 0, -8)
    hero:SetPoint("BOTTOMLEFT")
    hero:SetWidth(HERO_W)
    Kit.Fill(hero, C.panel, 0.85)
    Kit.Edge(hero, C.borderDim)
    local heroTop = hero:CreateTexture(nil, "ARTWORK")
    heroTop:SetPoint("TOPLEFT", 1, -1)
    heroTop:SetPoint("TOPRIGHT", -1, -1)
    heroTop:SetHeight(2)
    Kit.Paint(heroTop, C.accent, 0.9)
    local metal = hero:CreateTexture(nil, "BORDER", nil, 1)
    metal:SetPoint("TOPLEFT", 1, -1)
    metal:SetPoint("TOPRIGHT", -1, -1)
    metal:SetHeight(52)
    metal:SetTexture(CORE .. "header-metal")
    metal:SetAlpha(0.25)

    local nameText = Kit.Text(hero, "large", C.white)
    nameText:SetPoint("TOPLEFT", 14, -10)
    local infoText = Kit.Text(hero, "tiny", C.muted)
    infoText:SetPoint("TOPLEFT", nameText, "BOTTOMLEFT", 0, -4)
    local specButtons = {}
    local function specButton(i)
        local b = specButtons[i]
        if b then return b end
        b = CreateFrame("Button", nil, hero)
        b:SetSize(28, 28)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetPoint("TOPLEFT", 2, -2)
        b.icon:SetPoint("BOTTOMRIGHT", -2, 2)
        b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        Kit.Edge(b, C.borderDim)
        b.bar = b:CreateTexture(nil, "OVERLAY")
        b.bar:SetPoint("TOPLEFT", b, "BOTTOMLEFT", 2, -2)
        b.bar:SetPoint("TOPRIGHT", b, "BOTTOMRIGHT", -2, -2)
        b.bar:SetHeight(2)
        b:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:SetText(self.spec.name, 1, 1, 1)
            GameTooltip:AddLine(self.on and L.BIS_SPEC_OPEN or L.BIS_SPEC_SWITCH, C.muted[1], C.muted[2], C.muted[3])
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", Kit.HideTip)
        b:SetScript("OnClick", function(self)
            Kit.HideTip()
            if page.ClosePicker then page:ClosePicker() end
            Bis.SetSpec(self.spec.key, state.viewKey)
        end)
        specButtons[i] = b
        return b
    end
    local function paintSpecs()
        local specs = Bis.Specs(state.viewKey)
        local cur = Bis.SpecOf(state.viewKey)
        for i = #specs, 1, -1 do
            local b = specButton(i)
            local sp = specs[i]
            b.spec = sp
            b.on = sp.key == cur
            b.icon:SetTexture(sp.icon)
            b.icon:SetDesaturated(not b.on)
            b.icon:SetAlpha(b.on and 1 or 0.55)
            Kit.EdgeColor(b, b.on and C.accent or C.borderDim, b.on and 1 or 0.8)
            b.bar:SetColorTexture(RGB(C.accent, b.on and 1 or 0))
            b:ClearAllPoints()
            if i == #specs then b:SetPoint("TOPRIGHT", -12, -10) else b:SetPoint("RIGHT", specButtons[i + 1], "LEFT", -5, 0) end
            b:Show()
        end
        for i = #specs + 1, #specButtons do specButtons[i]:Hide() end
    end

    local stage = CreateFrame("Frame", nil, hero)
    stage:SetPoint("TOPLEFT", 1, -50)
    stage:SetPoint("RIGHT", -1, 0)
    stage:SetPoint("BOTTOM", 0, 184)
    local floor = stage:CreateTexture(nil, "BACKGROUND")
    floor:SetPoint("BOTTOM", 0, -10)
    floor:SetSize(HERO_W * 1.1, 120)
    floor:SetTexture(FDJ.Glyph("fc:glow-soft"))
    floor:SetBlendMode("ADD")
    floor:SetVertexColor(RGB(C.accent))
    floor:SetAlpha(0.35)
    local fade = Kit.Gradient(stage, "VERTICAL", C.accent, 0.10, 0, "BACKGROUND")
    fade:SetAllPoints()
    local model = CreateFrame("DressUpModel", nil, stage)
    model:SetPoint("TOPLEFT", 10 + SLOT + 6, -30)
    model:SetPoint("BOTTOMRIGHT", -(10 + SLOT + 6), SLOT + 12)
    model:EnableMouse(true)
    model:EnableMouseWheel(true)
    model.facing, model.zoom = 0, 0
    local function spin(self)
        if not self.dragX then return end
        local x = GetCursorPosition()
        self.facing = self.facing + (x - self.dragX) * 0.012
        self.dragX = x
        pcall(self.SetFacing, self, self.facing)
    end
    model:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" then
            self.dragX = GetCursorPosition()
            self:SetScript("OnUpdate", spin)
        else
            self.facing, self.zoom = 0, 0
            pcall(self.SetFacing, self, 0)
            pcall(self.SetPortraitZoom, self, 0)
        end
    end)
    local function dropOnModel()
        local kind, id = GetCursorInfo()
        if kind == "item" and id then
            ClearCursor()
            Bis.Add(id, state.viewKey)
            return true
        end
    end
    model:SetScript("OnReceiveDrag", dropOnModel)
    model:SetScript("OnMouseUp", function(self)
        dropOnModel()
        self.dragX = nil
        self:SetScript("OnUpdate", nil)
    end)
    model:SetScript("OnMouseWheel", function(self, delta)
        self.zoom = math.max(0, math.min(0.7, self.zoom + delta * 0.1))
        pcall(self.SetPortraitZoom, self, self.zoom)
    end)
    local look = Kit.Segmented(stage, { { "bis", L.BIS_VIEW_BIS }, { "worn", L.BIS_VIEW_WORN } }, function(key)
        state.look = key
        page:Dress()
    end)
    look:SetSize(160, 22)
    look:SetPoint("TOP", 0, -2)

    local slotButtons = {}
    local function slotButton(slot)
        local b = tile(stage, SLOT)
        b.slotID = slot
        b:SetFrameLevel(model:GetFrameLevel() + 5)
        b.hl = b:CreateTexture(nil, "HIGHLIGHT")
        b.hl:SetAllPoints()
        b.hl:SetColorTexture(1, 1, 1, 0.12)
        b.drop = b:CreateTexture(nil, "OVERLAY", nil, 2)
        b.drop:SetPoint("TOPLEFT", -6, 6)
        b.drop:SetPoint("BOTTOMRIGHT", 6, -6)
        b.drop:SetTexture(FDJ.Glyph("fc:glow-soft"))
        b.drop:SetBlendMode("ADD")
        b.drop:SetVertexColor(RGB(C.accent))
        b.drop:Hide()
        b.x = CreateFrame("Button", nil, b)
        b.x:SetSize(15, 15)
        b.x:SetPoint("TOPRIGHT", 4, 4)
        b.x:SetFrameLevel(b:GetFrameLevel() + 3)
        Kit.Fill(b.x, C.frame, 0.95)
        Kit.Edge(b.x, C.border)
        b.x.t = Kit.Glyph(b.x, "fc:icon-minus", 9, C.muted)
        b.x.t:SetPoint("CENTER")
        b.x:SetScript("OnMouseDown", function(self) self.t:SetPoint("CENTER", 0, -1) end)
        b.x:SetScript("OnMouseUp", function(self) self.t:SetPoint("CENTER") end)
        b.x:Hide()
        b.x:SetScript("OnClick", function()
            Kit.HideTip()
            if b.group then
                local _, index = groupOfSlot(b.slotID)
                Bis.ClearSlot(b.group, index, state.viewKey)
            end
        end)
        b.x:SetScript("OnEnter", function(self)
            Kit.EdgeColor(self, C.bad)
            self.t:SetVertexColor(RGB(C.bad))
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(L.BIS_REMOVE, 1, 1, 1)
            GameTooltip:Show()
        end)
        b.x:SetScript("OnLeave", function(self)
            Kit.EdgeColor(self, C.border)
            self.t:SetVertexColor(RGB(C.muted))
            Kit.HideTip()
            if not b:IsMouseOver() then b.x:Hide() end
        end)
        local function dropped(self)
            local kind, id = GetCursorInfo()
            if kind ~= "item" or not id then return false end
            ClearCursor()
            local g = Bis.GroupFor(id)
            if not g or g ~= self.group then
                FDJ.Print(L.BIS_WRONG_SLOT:format(self.group and Bis.Label(self.group) or "?"))
                return true
            end
            local _, index = groupOfSlot(self.slotID)
            if Bis.Find(id, state.viewKey) or Bis.Add(id, state.viewKey, true) then
                local list = Bis.Picks(g, state.viewKey)
                for k, v in ipairs(list) do
                    if v == id then table.remove(list, k) break end
                end
                table.insert(list, math.min(index or 1, #list + 1), id)
                FDJ:Emit("FDJ_WISHES")
            end
            return true
        end
        b:SetScript("OnReceiveDrag", dropped)
        b:SetScript("OnMouseUp", function(self)
            if GetCursorInfo() then
                self.justDropped = dropped(self)
            end
        end)
        b:SetScript("OnEnter", function(self)
            if self.itemID and mine() then self.x:Show() end
            if self.itemID then
                tipItem(self, self.itemID, L.BIS_DOLL_HINT, true)
            else
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(self.group and Bis.Label(self.group) or "", 1, 1, 1)
                GameTooltip:AddLine(L.BIS_SLOT_EMPTY_TIP, C.muted[1], C.muted[2], C.muted[3], true)
                GameTooltip:Show()
            end
        end)
        b:SetScript("OnLeave", function(self)
            if not self.x:IsMouseOver() then self.x:Hide() end
            Kit.HideTip()
        end)
        b:SetScript("OnClick", function(self, button)
            Kit.HideTip()
            if self.justDropped then self.justDropped = nil return end
            if GetCursorInfo() then return end
            if button == "RightButton" and self.itemID then
                local _, index = groupOfSlot(self.slotID)
                Bis.ClearSlot(self.group, index, state.viewKey)
            elseif IsShiftKeyDown() and self.itemID then
                local _, link = C_Item.GetItemInfo(self.itemID)
                if link then HandleModifiedItemClick(link) end
            elseif self.group then
                page:OpenPicker(self.group)
            end
        end)
        slotButtons[slot] = b
        return b
    end
    local hint = Kit.Text(view, "tiny", C.dim, "RIGHT")
    hint:SetText(L.BIS_DOLL_HELP)
    local function cursorGlow()
        local kind, id = GetCursorInfo()
        local g = kind == "item" and id and Bis.GroupFor(id)
        for _, b in pairs(slotButtons) do b.drop:SetShown(g and b.group == g or false) end
        hint:SetTextColor(RGB(g and C.accent or C.dim))
        hint:SetText(g and L.BIS_DOLL_DROP or L.BIS_DOLL_HELP)
    end
    FDJ:On("CURSOR_CHANGED", function() if view:IsVisible() then cursorGlow() end end)
    for _, slot in ipairs(LEFT_SLOTS) do slotButton(slot) end
    for _, slot in ipairs(RIGHT_SLOTS) do slotButton(slot) end
    for _, slot in ipairs(BOTTOM_SLOTS) do slotButton(slot) end

    local function layoutSlots()
        local h = stage:GetHeight()
        if h < 50 then return end
        local gap = 4
        local size = math.floor(math.max(20, math.min(40, (h - 30 - 8 - 6 - 7 * gap) / 9)))
        for i, slot in ipairs(LEFT_SLOTS) do
            local b = slotButtons[slot]
            b:SetSize(size, size)
            b:ClearAllPoints()
            b:SetPoint("TOPLEFT", 10, -30 - (i - 1) * (size + gap))
        end
        for i, slot in ipairs(RIGHT_SLOTS) do
            local b = slotButtons[slot]
            b:SetSize(size, size)
            b:ClearAllPoints()
            b:SetPoint("TOPRIGHT", -10, -30 - (i - 1) * (size + gap))
        end
        for i, slot in ipairs(BOTTOM_SLOTS) do
            local b = slotButtons[slot]
            b:SetSize(size, size)
            b:ClearAllPoints()
            b:SetPoint("BOTTOM", stage, "BOTTOM", (i - 2) * (size + gap), 6)
        end
        model:ClearAllPoints()
        model:SetPoint("TOPLEFT", 10 + size + 6, -30)
        model:SetPoint("BOTTOMRIGHT", -(10 + size + 6), size + 12)
    end
    stage:SetScript("OnSizeChanged", layoutSlots)
    layoutSlots()

    local run = CreateFrame("Button", nil, hero)
    run:SetPoint("BOTTOMLEFT", 10, 8)
    run:SetPoint("BOTTOMRIGHT", -10, 8)
    run:SetHeight(64)
    run.art = run:CreateTexture(nil, "BACKGROUND")
    run.art:SetPoint("TOPLEFT", 1, -1)
    run.art:SetPoint("BOTTOMRIGHT", -1, 1)
    run.shade = Kit.Gradient(run, "HORIZONTAL", C.frame, 0.95, 0.35, "BORDER")
    run.shade:SetAllPoints(run.art)
    Kit.Edge(run, C.borderDim)
    run.hl = run:CreateTexture(nil, "HIGHLIGHT")
    run.hl:SetAllPoints(run.art)
    run.hl:SetColorTexture(1, 1, 1, 0.06)
    run.head = Kit.Text(run, "tiny", C.accent)
    run.head:SetPoint("TOPLEFT", 12, -7)
    run.head:SetText(L.BIS_RUN_HEAD:upper())
    run.name = Kit.Text(run, "large", C.white)
    run.name:SetPoint("TOPLEFT", run.head, "BOTTOMLEFT", 0, -3)
    run.name:SetPoint("RIGHT", -30, 0)
    run.meta = Kit.Text(run, "tiny", C.text)
    run.meta:SetPoint("TOPLEFT", run.name, "BOTTOMLEFT", 0, -3)
    run.meta:SetPoint("RIGHT", -30, 0)
    run.arrow = Kit.Glyph(run, "fc:icon-chevron-right", 14, C.white)
    run.arrow:SetPoint("RIGHT", -12, 0)
    run:SetScript("OnClick", function()
        local d = Bis.RunNext()
        if d and FDJ.Journal then FDJ.Journal.Open(d, "overview") end
    end)
    run:SetScript("OnEnter", function(self)
        Kit.EdgeColor(self, C.accent)
        local d, n, items = Bis.RunNext()
        if not d then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(FDJ.DungeonTitle(d), 1, 1, 1)
        for _, id in ipairs(items or {}) do
            local name, qc = quality(id)
            local icon = C_Item.GetItemIconByID(id)
            GameTooltip:AddLine((icon and ("|T" .. icon .. ":16:16:0:0:64:64:5:59:5:59|t ") or "") .. (name or L.LOADING),
                qc and qc[1] or 1, qc and qc[2] or 1, qc and qc[3] or 1)
        end
        GameTooltip:Show()
    end)
    run:SetScript("OnLeave", function(self)
        Kit.EdgeColor(self, C.borderDim)
        Kit.HideTip()
    end)

    local weightsFrame

    local Stats = Bis.Stats
    local paintTile
    local gs = CreateFrame("Frame", nil, hero)
    gs:SetPoint("BOTTOMLEFT", 10, 80)
    gs:SetPoint("BOTTOMRIGHT", -10, 80)
    gs:SetHeight(96)
    Kit.Fill(gs, C.field, 0.85)
    Kit.Edge(gs, C.borderDim)
    gs.head = Kit.Text(gs, "tiny", C.accent)
    gs.head:SetPoint("TOPLEFT", 12, -8)
    gs.head:SetText(L.BIS_GS_TITLE:upper())
    gs.weights = Kit.IconButton(gs, "fc:icon-gear", 22, L.BIS_WEIGHTS, function() page:OpenWeights() end)
    gs.weights:SetPoint("TOPRIGHT", -6, -5)
    gs.all = Kit.Button(gs, L.BIS_ALL_STATS, nil, 22, function() page:OpenStats() end, nil, "fc:icon-chevron-right")
    gs.all:SetPoint("RIGHT", gs.weights, "LEFT", -4, 0)
    gs.value = Kit.Text(gs, "huge", C.white)
    gs.value:SetPoint("TOPLEFT", gs.head, "BOTTOMLEFT", 0, -3)
    gs.delta = Kit.Text(gs, "normal", C.good)
    gs.delta:SetPoint("BOTTOMLEFT", gs.value, "BOTTOMRIGHT", 6, 3)
    gs.label = Kit.Text(gs, "tiny", C.muted)
    gs.label:SetPoint("BOTTOMLEFT", gs.delta, "BOTTOMRIGHT", 6, 0)
    gs.from = Kit.Text(gs, "tiny", C.muted, "RIGHT")
    gs.from:SetPoint("RIGHT", gs.all, "LEFT", -10, 0)

    gs.track = CreateFrame("Frame", nil, gs)
    gs.track:SetPoint("TOPLEFT", gs.value, "BOTTOMLEFT", 0, -6)
    gs.track:SetPoint("RIGHT", gs, "RIGHT", -12, 0)
    gs.track:SetHeight(7)
    gs.cells = {}
    local STRIP_SLOTS = {}
    for _, g in ipairs(Bis.GROUPS) do
        if not g.optional then
            for _, slot in ipairs(g.slots) do STRIP_SLOTS[#STRIP_SLOTS + 1] = slot end
        end
    end
    for i, slot in ipairs(STRIP_SLOTS) do
        local c = CreateFrame("Button", nil, gs.track)
        c.slotID = slot
        c:SetHeight(7)
        c.tex = c:CreateTexture(nil, "ARTWORK")
        c.tex:SetAllPoints()
        c:SetScript("OnEnter", function(self)
            local g = groupOfSlot(self.slotID)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(SLOT_LABEL[self.slotID] or (g and Bis.Label(g)) or "", 1, 1, 1)
            if self.status then GameTooltip:AddLine(self.status, C.muted[1], C.muted[2], C.muted[3]) end
            GameTooltip:Show()
        end)
        c:SetScript("OnLeave", Kit.HideTip)
        c:SetScript("OnClick", function(self)
            local g = groupOfSlot(self.slotID)
            if g then page:OpenPicker(g) end
        end)
        gs.cells[i] = c
    end
    gs.track:SetScript("OnSizeChanged", function(self, w)
        local n = #gs.cells
        local each = (w - (n - 1) * 2) / n
        for i, c in ipairs(gs.cells) do
            c:ClearAllPoints()
            c:SetPoint("LEFT", (i - 1) * (each + 2), 0)
            c:SetWidth(math.max(1, each))
        end
    end)
    gs.gains = {}
    for i = 1, 4 do
        local col, row = (i - 1) % 2, math.floor((i - 1) / 2)
        local t = {}
        t.name = Kit.Text(gs, "small", C.text)
        t.name:SetPoint("TOPLEFT", gs.track, "BOTTOMLEFT", col * 158, -8 - row * 16)
        t.name:SetWidth(100)
        t.name:SetJustifyH("LEFT")
        t.value = Kit.Text(gs, "small", C.good, "RIGHT")
        t.value:SetPoint("TOPRIGHT", gs.track, "BOTTOMLEFT", col * 158 + 148, -8 - row * 16)
        t.value:SetWidth(48)
        gs.gains[i] = t
    end
    gs.none = Kit.Text(gs, "small", C.dim)
    gs.none:SetPoint("TOPLEFT", gs.track, "BOTTOMLEFT", 0, -10)

    local right = CreateFrame("Frame", nil, view)
    right:SetPoint("TOPLEFT", hero, "TOPRIGHT", 12, 0)
    right:SetPoint("BOTTOMRIGHT")
    local listCard = card(right)
    listCard:SetAllPoints()

    local head = CreateFrame("Frame", nil, listCard)
    head:SetPoint("TOPLEFT", 16, -10)
    head:SetPoint("TOPRIGHT", -16, -10)
    head:SetHeight(24)
    local count = Kit.Text(head, "large", C.white)
    count:SetPoint("LEFT")
    local countLabel = Kit.Text(head, "tiny", C.muted)
    countLabel:SetPoint("BOTTOMLEFT", count, "BOTTOMRIGHT", 6, 2)
    state.filter = "all"
    local filter = Kit.Segmented(head, { { "all", "" }, { "missing", "" }, { "bags", "" }, { "worn", "" } }, function(key)
        state.filter = key
        page:PaintList()
    end)
    filter:SetSize(320, 24)
    filter:SetPoint("RIGHT")
    filter:Select("all", true)

    hint:SetParent(listCard)
    hint:SetPoint("BOTTOMRIGHT", listCard, "BOTTOMRIGHT", -16, 6)
    local listScroll = Kit.Scroller(listCard)
    listScroll:SetPoint("TOPLEFT", head, "BOTTOMLEFT", 0, -6)
    listScroll:SetPoint("BOTTOMRIGHT", -8, 20)
    local table_ = listScroll.content

    local ORDER = {
        { L.BIS_SEC_ARMOR, { 1, 2, 3, 15, 5, 9, 10, 6, 7, 8, 19 } },
        { L.BIS_SEC_JEWELRY, { 11, 12, 13, 14 } },
        { L.BIS_SEC_WEAPONS, { 16, 17, 18 } },
    }
    local COL = { slot = 62, icon = 24, gain = 50, drop = 46 }
    local colHeads = {}
    for i, key in ipairs({ "BIS_COL_ITEM", "BIS_COL_SOURCE", "BIS_COL_FROM", "BIS_COL_CHANCE", "BIS_COL_UPGRADE" }) do
        local t = Kit.Text(table_, "tiny", C.dim, i >= 4 and "RIGHT" or "LEFT")
        t:SetText(L[key]:upper())
        colHeads[i] = t
    end
    local slotRows, sectionHeads = {}, {}

    local function slotRow(slot)
        local r = CreateFrame("Button", nil, table_)
        r.slotID = slot
        r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        r.bg = r:CreateTexture(nil, "BACKGROUND")
        r.bg:SetAllPoints()
        r.bg:SetColorTexture(0, 0, 0, 0)
        r.hl = r:CreateTexture(nil, "HIGHLIGHT")
        r.hl:SetAllPoints()
        r.hl:SetColorTexture(1, 1, 1, 0.035)
        r.drop = r:CreateTexture(nil, "OVERLAY", nil, 2)
        r.drop:SetAllPoints()
        r.drop:SetColorTexture(RGB(C.accent, 0.16))
        r.drop:Hide()

        r.mark = r:CreateTexture(nil, "ARTWORK")
        r.mark:SetPoint("TOPLEFT", 0, -6)
        r.mark:SetPoint("BOTTOMLEFT", 0, 6)
        r.mark:SetWidth(2)
        r.slotName = Kit.Text(r, "tiny", C.dim)
        r.slotName:SetPoint("LEFT", 10, 0)
        r.slotName:SetWidth(COL.slot - 10)
        r.tile = tile(r, COL.icon)
        r.tile:SetPoint("LEFT", COL.slot, 0)
        r.tile:EnableMouse(false)
        r.tile.check:SetSize(12, 12)
        r.name = Kit.Text(r, "small", C.white)
        r.name:SetPoint("LEFT", r.tile, "RIGHT", 9, 0)
        r.gain = Kit.Text(r, "small", C.good, "RIGHT")
        r.gain:SetPoint("RIGHT", -8, 0)
        r.gain:SetWidth(COL.gain)
        r.drop = Kit.Text(r, "small", C.amber, "RIGHT")
        r.drop:SetPoint("RIGHT", r.gain, "LEFT", -12, 0)
        r.drop:SetWidth(COL.drop)
        r.where = Kit.Text(r, "small", C.muted)
        r.from = Kit.Text(r, "small", C.muted)
        r.use = Kit.Button(r, L.BIS_USE, nil, 20, function()
            Kit.HideTip()
            if r.suggestID then Bis.Add(r.suggestID, state.viewKey, true) end
        end, nil, "fc:icon-plus")
        r.use:SetPoint("RIGHT", -6, 0)
        r.use.label:SetTextColor(RGB(C.muted))
        r.use:HookScript("OnEnter", function(self) self.label:SetTextColor(RGB(C.white)) end)
        r.use:HookScript("OnLeave", function(self) self.label:SetTextColor(RGB(C.muted)) end)
        r.use:Hide()
        r.remove = Kit.IconButton(r, "fc:icon-minus", 20, L.BIS_REMOVE, function()
            Kit.HideTip()
            if r.group then Bis.ClearSlot(r.group, r.index, state.viewKey) end
        end)
        r.remove:SetPoint("RIGHT", -6, 0)
        r.remove:Hide()
        local function dropped(self)
            local kind, id = GetCursorInfo()
            if kind ~= "item" or not id then return false end
            ClearCursor()
            local g = Bis.GroupFor(id)
            if not g or g ~= self.group then
                FDJ.Print(L.BIS_WRONG_SLOT:format(self.group and Bis.Label(self.group) or "?"))
                return true
            end
            if Bis.Find(id, state.viewKey) or Bis.Add(id, state.viewKey, true) then
                local list = Bis.Picks(g, state.viewKey)
                for k, v in ipairs(list) do
                    if v == id then table.remove(list, k) break end
                end
                table.insert(list, math.min(self.index or 1, #list + 1), id)
                FDJ:Emit("FDJ_WISHES")
            end
            return true
        end
        r:SetScript("OnReceiveDrag", dropped)
        r:SetScript("OnMouseUp", function(self)
            if GetCursorInfo() then self.justDropped = dropped(self) end
        end)
        r:SetScript("OnEnter", function(self)
            if self.itemID and mine() then
                self.gain:Hide()
                self.remove:Show()
                tipItem(self, self.itemID, L.BIS_ROW_HINT, true)
            elseif self.itemID then
                tipItem(self, self.itemID, nil, false)
            elseif self.suggestID then
                tipItem(self, self.suggestID, L.BIS_SUGGEST_HINT, true)
            else
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:SetText(self.group and Bis.Label(self.group) or "", 1, 1, 1)
                GameTooltip:AddLine(L.BIS_SLOT_EMPTY_TIP, C.muted[1], C.muted[2], C.muted[3], true)
                GameTooltip:Show()
            end
        end)
        r:SetScript("OnLeave", function(self)
            if not self.remove:IsMouseOver() then
                self.remove:Hide()
                self.gain:Show()
            end
            Kit.HideTip()
        end)
        r.remove:HookScript("OnLeave", function()
            if not r:IsMouseOver() then
                r.remove:Hide()
                r.gain:Show()
            end
        end)
        r:SetScript("OnClick", function(self, button)
            Kit.HideTip()
            if self.justDropped then self.justDropped = nil return end
            if GetCursorInfo() then return end
            if button == "RightButton" then
                if self.itemID and self.group then Bis.ClearSlot(self.group, self.index, state.viewKey) end
            elseif IsShiftKeyDown() and self.itemID then
                local _, link = C_Item.GetItemInfo(self.itemID)
                if link then HandleModifiedItemClick(link) end
            elseif self.group then
                page:OpenPicker(self.group)
            end
        end)
        slotRows[slot] = r
        return r
    end
    for gi, sec in ipairs(ORDER) do
        for _, slot in ipairs(sec[2]) do slotRow(slot) end
        local h = Kit.Text(table_, "tiny", C.accent)
        h:SetText(sec[1]:upper())
        sectionHeads[gi] = h
    end
    FDJ:On("CURSOR_CHANGED", function()
        if not view:IsVisible() then return end
        local kind, id = GetCursorInfo()
        local g = kind == "item" and id and Bis.GroupFor(id)
        for _, r in pairs(slotRows) do r.drop:SetShown(g and r.group == g or false) end
    end)

    local suggested = {}
    local function suggestionFor(g)
        if g.optional then return nil end
        local key = g.key
        local hit = suggested[key]
        if hit ~= nil then return hit or nil end
        local list, waiting = Bis.Suggest.Ranked(g)
        local e = list[1]
        if e then
            suggested[key] = e.id
        elseif waiting == 0 then
            suggested[key] = false
        end
        return e and e.id or nil
    end
    local function forgetSuggestions(keys)
        if type(keys) == "table" then
            for key in pairs(keys) do suggested[key] = nil end
        else
            wipe(suggested)
        end
    end
    FDJ:On("FDJ_BIS_ITEMS", forgetSuggestions)
    FDJ:On("FDJ_BIS_WEIGHTS", forgetSuggestions)
    FDJ:On("PLAYER_LEVEL_UP", forgetSuggestions)

    local function sourceCols(itemID)
        local boss, odds = Bis.Source(itemID)
        if boss then return FDJ.DungeonTitle(boss.dungeon), boss.n, odds and (odds .. "%") or nil end
        local q = Bis.QuestFor(itemID)
        if q then return (q.at and q.at ~= "") and q.at or L.BIS_QUEST, L.BIS_FROM_QUEST:format(q.t), nil end
        return nil
    end

    local function slotScore(id, weights)
        return id and Stats.ItemScore(id, weights) or 0
    end

    function page:PaintList()
        local isMine = mine()
        local owner = isMine and FDJ.char or FDJ.db.chars[state.viewKey]
        local weights = Stats.Weights(owner and owner.class, Bis.SpecOf(state.viewKey))
        local counts = { all = 0, missing = 0, bags = 0, worn = 0 }
        local sections = {}
        for gi, sec in ipairs(ORDER) do
            local shown = {}
            for _, slot in ipairs(sec[2]) do
                local r = slotRows[slot]
                local g, index = groupOfSlot(slot)
                r.group, r.index = g, index
                local id = g and Bis.Picks(g, state.viewKey)[index]
                r.itemID = id
                local st = "empty"
                if id then
                    local sv = isMine and Bis.State(g, id) or "missing"
                    st = sv == "equipped" and "worn" or (sv == "owned" and "bags" or "missing")
                    counts[st] = counts[st] + 1
                end
                if not (g and g.optional and not id) then counts.all = counts.all + 1 end
                r.st = st

                local hide = (g and g.optional and not id and state.filter ~= "all")
                if not hide and (state.filter == "all" or state.filter == st) then
                    shown[#shown + 1] = r
                else
                    r:Hide()
                end
            end
            sections[gi] = shown
        end

        count:SetText(("%d|cff7f8590/%d|r"):format(counts.worn, counts.all))
        countLabel:SetText(isMine and L.BIS_WORN_OF or L.BIS_SLOTS_PICKED)
        filter.buttons[1].t:SetText(L.BIS_F_ALL)
        filter.buttons[2].t:SetText(L.BIS_F_MISSING:format(counts.missing))
        filter.buttons[3].t:SetText(L.BIS_F_BAGS:format(counts.bags))
        filter.buttons[4].t:SetText(L.BIS_F_WORN:format(counts.worn))
        filter:SetShown(isMine)

        local W = table_:GetWidth()
        if W < 240 then return end
        local n, heads = 0, 0
        for _, shown in ipairs(sections) do
            n = n + #shown
            if #shown > 0 then heads = heads + 1 end
        end
        local h = listScroll:GetHeight()
        local rh = n > 0 and math.floor((h - 16 - heads * 26) / n) or 30
        rh = math.max(26, math.min(36, rh))
        local free = W - COL.slot - COL.icon - 9 - COL.gain - COL.drop - 8 - 12 - 12 - 24
        local nameW = math.floor(free * 0.40)
        local whereW = math.floor(free * 0.32)
        local fromW = free - nameW - whereW

        local nameX = COL.slot + COL.icon + 9
        colHeads[1]:ClearAllPoints()
        colHeads[1]:SetPoint("TOPLEFT", nameX, -2)
        colHeads[2]:ClearAllPoints()
        colHeads[2]:SetPoint("TOPLEFT", nameX + nameW + 12, -2)
        colHeads[3]:ClearAllPoints()
        colHeads[3]:SetPoint("TOPLEFT", nameX + nameW + 12 + whereW + 12, -2)
        colHeads[4]:ClearAllPoints()
        colHeads[4]:SetPoint("TOPRIGHT", -(8 + COL.gain + 12), -2)
        colHeads[4]:SetWidth(COL.drop)
        colHeads[5]:ClearAllPoints()
        colHeads[5]:SetPoint("TOPRIGHT", -8, -2)
        colHeads[5]:SetWidth(COL.gain)
        local y = 16
        for gi, shown in ipairs(sections) do
            local hd = sectionHeads[gi]
            if #shown == 0 then
                hd:Hide()
            else
                hd:ClearAllPoints()
                hd:SetPoint("TOPLEFT", 10, -(y + 6))
                hd:Show()
                y = y + 22
            end
            for i, r in ipairs(shown) do
                r:ClearAllPoints()
                r:SetPoint("TOPLEFT", 0, -y)
                r:SetPoint("RIGHT", table_, "RIGHT")
                r:SetHeight(rh)
                r.name:SetWidth(nameW)
                r.where:ClearAllPoints()
                r.where:SetPoint("LEFT", r.name, "RIGHT", 12, 0)
                r.where:SetWidth(whereW)
                r.from:ClearAllPoints()
                r.from:SetPoint("LEFT", r.where, "RIGHT", 12, 0)
                r.from:SetWidth(fromW)
                r.slotName:SetText((SLOT_LABEL[r.slotID] or (r.group and Bis.Label(r.group)) or ""):upper())
                paintTile(r.tile, r.group, r.itemID, r.slotID, isMine)
                r.tile.icon:SetAlpha(1)
                r.suggestID = nil
                r.remove:Hide()
                r.use:Hide()
                r.gain:Show()
                local id = r.itemID
                local tone = r.st == "worn" and C.good or r.st == "bags" and C.amber or r.st == "missing" and C.borderDim or nil
                r.mark:SetColorTexture(RGB(tone or C.borderDim, tone and 1 or 0))
                if id then
                    local name, qc = quality(id)
                    r.slotName:SetTextColor(RGB(C.muted))
                    r.name:SetText(name or L.LOADING)
                    r.name:SetTextColor(RGB(qc or C.text))
                    local a, b, c = sourceCols(id)
                    r.where:SetText(a or FDJ.Paint("dim", L.BIS_SOURCE_NONE))
                    r.where:SetTextColor(RGB(C.text))
                    r.from:SetText(b or "")
                    r.from:SetTextColor(RGB(C.muted))
                    r.drop:SetText(c or "")
                    r.drop:SetTextColor(RGB(C.amber))
                    local worn = isMine and GetInventoryItemID("player", r.slotID)
                    if isMine and r.st == "worn" then
                        r.gain:SetText(FDJ.Paint("good", L.BIS_STATUS_WORN))
                    elseif isMine and worn ~= id then
                        local text, color = gainText(slotScore(worn, weights), slotScore(id, weights))
                        r.gain:SetText(text)
                        if color then r.gain:SetTextColor(RGB(C[color])) end
                    else
                        r.gain:SetText("")
                    end
                else
                    r.slotName:SetTextColor(RGB(C.dim))
                    local sid = isMine and suggestionFor(r.group) or nil
                    r.suggestID = sid
                    if sid then
                        local name, qc = quality(sid)
                        r.tile.icon:SetTexture(C_Item.GetItemIconByID(sid) or 134400)
                        r.tile.icon:SetAlpha(0.35)
                        r.tile.icon:Show()
                        r.tile.slot:Hide()
                        Kit.EdgeColor(r.tile, qc or C.borderDim, 0.3)
                        r.name:SetText(name or L.LOADING)
                        r.name:SetTextColor(RGB(qc or C.muted, 0.45))
                        local a, b, c = sourceCols(sid)
                        r.where:SetText(a or "")
                        r.where:SetTextColor(RGB(C.muted, 0.6))
                        r.from:SetText(b or "")
                        r.from:SetTextColor(RGB(C.dim, 0.9))
                        r.drop:SetText(c or "")
                        r.drop:SetTextColor(RGB(C.dim, 0.9))
                        r.gain:Hide()
                        r.use:Show()
                    else
                        r.name:SetText(FDJ.Paint("dim", (r.group and r.group.optional) and L.BIS_OPTIONAL or (isMine and L.BIS_CHOOSE or L.BIS_SLOT_EMPTY_SHORT)))
                        r.where:SetText("")
                        r.from:SetText("")
                        r.drop:SetText("")
                        r.gain:SetText("")
                    end
                end
                r:Show()
                y = y + rh
            end
            if #shown > 0 then y = y + 4 end
        end
        listScroll:SetContentHeight(y)
    end
    listScroll:HookScript("OnSizeChanged", function() if view:IsVisible() then later() end end)

    local statsFrame
    local COLW = 96
    local function colText(parent, size, color)
        local t = {}
        t.name = Kit.Text(parent, size, color)
        t.name:SetPoint("LEFT", 10, 0)
        t.now = Kit.Text(parent, size, color, "RIGHT")
        t.bis = Kit.Text(parent, size, color, "RIGHT")
        t.diff = Kit.Text(parent, size, color, "RIGHT")
        t.diff:SetPoint("RIGHT", -10, 0)
        t.diff:SetWidth(COLW - 20)
        t.bis:SetPoint("RIGHT", t.diff, "LEFT", -10, 0)
        t.bis:SetWidth(COLW)
        t.now:SetPoint("RIGHT", t.bis, "LEFT", -10, 0)
        t.now:SetWidth(COLW)
        t.name:SetPoint("RIGHT", t.now, "LEFT", -10, 0)
        return t
    end

    local function fmt(v, pct)
        if not v then return FDJ.Paint("dim", "-") end
        local n = math.abs(v - math.floor(v)) > 0.05 and ("%.1f"):format(v) or tostring(math.floor(v + 0.5))
        return pct and (n .. "%") or n
    end

    local function sheets(isMine)
        local bisSet = Stats.BisSet(state.viewKey, isMine)
        local bis, bisFx, missing = Stats.Sum(bisSet)
        if not isMine then return nil, bis, nil, bisFx, missing, nil, bis end
        local now, nowFx, m2 = Stats.Sum(Stats.Worn("player"))
        local base = {}
        for i, id in ipairs({ "STR", "AGI", "STA", "INT", "SPI" }) do
            local _, value = UnitStat("player", i)
            if value then base[id] = value - (now[id] or 0) end
        end
        local _, armor = UnitArmor("player")
        if armor then base.ARMOR = armor - (now.ARMOR or 0) - 2 * (now.AGI or 0) end
        local nowT, bisT = {}, {}
        for k, v in pairs(now) do nowT[k] = v end
        for k, v in pairs(bis) do bisT[k] = v end
        for k, v in pairs(base) do
            nowT[k] = (nowT[k] or 0) + v
            bisT[k] = (bisT[k] or 0) + v
        end
        if base.ARMOR then
            nowT.ARMOR = nowT.ARMOR + 2 * (now.AGI or 0)
            bisT.ARMOR = bisT.ARMOR + 2 * (bis.AGI or 0)
        end
        nowT.HEALTH = UnitHealthMax("player")
        bisT.HEALTH = nowT.HEALTH + 10 * ((bis.STA or 0) - (now.STA or 0))
        if (UnitPowerMax("player", 0) or 0) > 0 and UnitPowerType("player") == 0 then
            nowT.MANA = UnitPowerMax("player", 0)
            bisT.MANA = nowT.MANA + 15 * ((bis.INT or 0) - (now.INT or 0))
        end
        return nowT, bisT, nowFx, bisFx, missing + m2, now, bis
    end

    local STAT_SECTIONS = {
        { "attr", L.BIS_SEC_ATTR }, { "off", L.BIS_SEC_OFF }, { "def", L.BIS_SEC_DEF }, { "res", L.BIS_SEC_RES },
    }

    local function buildStats()
        local f = card(view)
        f:SetPoint("TOPLEFT", right, "TOPLEFT")
        f:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT")
        f:SetFrameLevel(right:GetFrameLevel() + 25)
        f:EnableMouse(true)
        Kit.Fill(f, C.frame, 0.97, "BACKGROUND", -1)
        f.title = Kit.Text(f, "large", C.white)
        f.title:SetPoint("TOPLEFT", 16, -14)
        f.title:SetText(L.BIS_ALL_STATS)
        f.close = Kit.CloseButton(f, function() f:Hide() end)
        f.close:SetPoint("TOPRIGHT", -6, -6)
        backable(f, f.title)
        local cols = CreateFrame("Frame", nil, f)
        cols:SetPoint("TOPLEFT", 16, -48)
        cols:SetPoint("TOPRIGHT", -16, -48)
        cols:SetHeight(20)
        f.headers = colText(cols, "tiny", C.dim)
        f.headers.name:SetText(L.BIS_COL_STAT:upper())
        f.headers.now:SetText(L.BIS_COL_NOW:upper())
        f.headers.bis:SetText(L.BIS_COL_BIS:upper())
        f.headers.diff:SetText(L.BIS_COL_DIFF:upper())
        local rule = f:CreateTexture(nil, "BORDER")
        rule:SetPoint("TOPLEFT", cols, "BOTTOMLEFT", 0, -2)
        rule:SetPoint("TOPRIGHT", cols, "BOTTOMRIGHT", 0, -2)
        rule:SetHeight(1)
        Kit.Paint(rule, C.borderDim)
        f.scroll = Kit.Scroller(f)
        f.scroll:SetPoint("TOPLEFT", cols, "BOTTOMLEFT", 0, -6)
        f.scroll:SetPoint("BOTTOMRIGHT", -8, 8)
        f.rows = Kit.Pool(function()
            local r = CreateFrame("Frame", nil, f.scroll.content)
            r:SetHeight(22)
            r.bg = r:CreateTexture(nil, "BACKGROUND")
            r.bg:SetAllPoints()
            local t = colText(r, "small", C.text)
            r.name, r.now, r.bis, r.diff = t.name, t.now, t.bis, t.diff
            r.full = Kit.Text(r, "small", C.good)
            r.full:SetPoint("LEFT", 10, 0)
            r.full:SetPoint("RIGHT", -10, 0)
            return r
        end)
        f:Hide()
        return f
    end

    local function paintTable(nowT, bisT, nowFx, bisFx, missing, isMine)
        local f = statsFrame
        f.headers.now:SetShown(isMine)
        f.headers.diff:SetShown(isMine)
        f.rows:Reset()
        local width = math.max(300, f.scroll:GetWidth() - 10)
        f.scroll.content:SetWidth(width)
        local y, n = 0, 0
        local function row()
            local r = f.rows:Get()
            r:SetPoint("TOPLEFT", 0, -y)
            r:SetPoint("RIGHT", f.scroll.content, "RIGHT")
            r.name:SetText("")
            r.now:SetText("")
            r.bis:SetText("")
            r.diff:SetText("")
            r.full:SetText("")
            return r
        end
        local function head(text)
            y = y + 6
            local r = row()
            r.bg:SetColorTexture(0, 0, 0, 0)
            Kit.SetFont(r.full, "tiny")
            r.full:SetText(FDJ.Paint("accent", text:upper()))
            y = y + 22
            n = 0
        end
        local function line(label, a, b, pct)
            if (a or 0) == 0 and (b or 0) == 0 then return end
            local r = row()
            n = n + 1
            r.bg:SetColorTexture(RGB(C.panel, n % 2 == 0 and 0.25 or 0.55))
            r.name:SetText(label)
            r.bis:SetText(fmt(b or 0, pct))
            r.bis:SetTextColor(RGB(C.white))
            if isMine then
                r.now:SetText(fmt(a or 0, pct))
                r.now:SetTextColor(RGB(C.muted))
                local d = (b or 0) - (a or 0)
                if math.abs(d) < 0.05 then
                    r.diff:SetText(FDJ.Paint("dim", "-"))
                else
                    r.diff:SetText(FDJ.Paint(d > 0 and "good" or "bad", (d > 0 and "+" or "-") .. fmt(math.abs(d), pct)))
                end
            end
            y = y + 22
        end
        nowT = nowT or {}
        for _, sec in ipairs(STAT_SECTIONS) do
            local any = sec[1] == "def" and (nowT.HEALTH or bisT.HEALTH) and true or false
            for _, st in ipairs(Stats.LIST) do
                if st.group == sec[1] and ((nowT[st.id] or 0) ~= 0 or (bisT[st.id] or 0) ~= 0) then any = true end
            end
            if any then
                head(sec[2])
                if sec[1] == "def" then
                    line(L.BIS_HEALTH, nowT.HEALTH, bisT.HEALTH)
                    line(L.BIS_MANA, nowT.MANA, bisT.MANA)
                end
                for _, st in ipairs(Stats.LIST) do
                    if st.group == sec[1] then line(st.label, nowT[st.id], bisT[st.id], st.pct) end
                end
            end
        end
        local have = {}
        for _, e in ipairs(nowFx or {}) do have[e] = (have[e] or 0) + 1 end
        if #(bisFx or {}) > 0 then
            head(L.BIS_SEC_FX)
            for _, e in ipairs(bisFx) do
                local r = row()
                n = n + 1
                r.bg:SetColorTexture(RGB(C.panel, n % 2 == 0 and 0.25 or 0.55))
                Kit.SetFont(r.full, "small")
                local new = isMine and not (have[e] and have[e] > 0)
                if have[e] then have[e] = have[e] - 1 end
                r.full:SetText((new and FDJ.Paint("good", "+ ") or "") .. FDJ.Paint("good", e))
                y = y + 22
            end
        end
        if missing and missing > 0 then head(L.BIS_LOADING_N:format(missing)) end
        f.scroll:SetContentHeight(y + 8)
    end

    function page:PaintStats()
        local isMine = mine()
        local nowT, bisT, nowFx, bisFx, missing, nowGear, bisGear = sheets(isMine)
        local owner = isMine and FDJ.char or FDJ.db.chars[state.viewKey]
        local weights = Stats.Weights(owner and owner.class, Bis.SpecOf(state.viewKey))
        local bisScore = math.floor(Stats.Score(bisGear, weights) + 0.5)
        gs.value:SetText(tostring(bisScore))
        gs.label:SetText(L.BIS_GS_WITH)
        local gains = {}
        for _, c in ipairs(gs.cells) do
            local g, index = groupOfSlot(c.slotID)
            local id = g and Bis.Picks(g, state.viewKey)[index]
            local st = "empty"
            if id then
                local sv = isMine and Bis.State(g, id) or "missing"
                st = sv == "equipped" and "worn" or (sv == "owned" and "bags" or "missing")
            end
            local tone = st == "worn" and C.good or st == "bags" and C.amber or st == "missing" and C.muted or C.panel
            c.tex:SetColorTexture(RGB(tone, st == "empty" and 1 or 0.9))
            c.status = L[STATUS[st].key]
        end
        if isMine then
            local nowScore = math.floor(Stats.Score(nowGear, weights) + 0.5)
            local d = bisScore - nowScore
            gs.delta:SetText(d ~= 0 and ("%+d"):format(d) or "")
            gs.delta:SetTextColor(RGB(d >= 0 and C.good or C.bad))
            gs.from:SetText(L.BIS_GS_CURRENT:format(nowScore))
            for _, st in ipairs(Stats.LIST) do
                local diff = (bisGear[st.id] or 0) - (nowGear[st.id] or 0)
                if math.abs(diff) >= 0.05 then
                    gains[#gains + 1] = { st = st, diff = diff, weight = math.abs(diff) * (weights[st.id] or 0.001) }
                end
            end
        else
            gs.from:SetText("")
            gs.delta:SetText("")
            for _, st in ipairs(Stats.LIST) do
                local v = bisGear[st.id] or 0
                if v ~= 0 then gains[#gains + 1] = { st = st, diff = v, weight = math.abs(v) * (weights[st.id] or 0.001) } end
            end
        end
        table.sort(gains, function(a, b) return a.weight > b.weight end)
        for i, t in ipairs(gs.gains) do
            local e = gains[i]
            if e then
                t.name:SetText(e.st.label)
                t.value:SetText((e.diff > 0 and "+" or "-") .. fmt(math.abs(e.diff), e.st.pct))
                t.value:SetTextColor(RGB(e.diff > 0 and C.good or C.bad))
                t.name:Show()
                t.value:Show()
            else
                t.name:Hide()
                t.value:Hide()
            end
        end
        gs.none:SetText(#gains == 0 and L.BIS_GS_NONE or "")
        if statsFrame and statsFrame:IsShown() then paintTable(nowT, bisT, nowFx, bisFx, missing, isMine) end
    end

    function page:OpenStats()
        statsFrame = statsFrame or buildStats()
        if page.ClosePicker then page:ClosePicker() end
        if weightsFrame then weightsFrame:Hide() end
        statsFrame:Show()
        page:PaintStats()
    end

    local function buildWeights()
        local f = card(view)
        f:SetPoint("TOPLEFT", right, "TOPLEFT")
        f:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT")
        f:SetFrameLevel(right:GetFrameLevel() + 25)
        f:EnableMouse(true)
        Kit.Fill(f, C.frame, 0.97, "BACKGROUND", -1)
        f.title = Kit.Text(f, "large", C.white)
        f.title:SetPoint("TOPLEFT", 16, -14)
        f.title:SetText(L.BIS_WEIGHTS)
        f.close = Kit.CloseButton(f, function() f:Hide() end)
        f.close:SetPoint("TOPRIGHT", -6, -6)
        backable(f, f.title)
        f.sub = Kit.Text(f, "tiny", C.muted)
        f.sub:SetPoint("TOPLEFT", f.back, "BOTTOMLEFT", 2, -8)
        f.reset = Kit.Button(f, L.BIS_WEIGHTS_RESET, nil, 26, function()
            Stats.ResetWeights(nil, f.spec)
        end, nil, "fc:icon-reset")
        f.reset:SetPoint("RIGHT", f.close, "LEFT", -8, 0)
        f.export = Kit.Button(f, L.EXPORT, nil, 26, function()
            Kit.TextWindow(L.BIS_WEIGHTS, Stats.Export(nil, f.spec), nil, L.BIS_WEIGHTS_EXPORT_HINT)
        end)
        f.export:SetPoint("RIGHT", f.reset, "LEFT", -6, 0)
        f.import = Kit.Button(f, L.IMPORT, nil, 26, function()
            Kit.TextWindow(L.BIS_WEIGHTS, "", function(text) return Stats.Import(text, nil, f.spec) end, L.BIS_WEIGHTS_IMPORT_HINT)
        end)
        f.import:SetPoint("RIGHT", f.export, "LEFT", -6, 0)

        f.specs = {}
        f.rows = {}
        local list = CreateFrame("Frame", nil, f)
        list:SetPoint("TOPLEFT", 16, -96)
        list:SetPoint("BOTTOMLEFT", 16, 12)
        list:SetWidth(330)
        local up = CreateFrame("Frame", nil, f)
        up:SetPoint("TOPLEFT", list, "TOPRIGHT", 24, 0)
        up:SetPoint("BOTTOMRIGHT", -16, 12)
        up.head = Kit.Text(up, "tiny", C.accent)
        up.head:SetPoint("TOPLEFT")
        up.head:SetText(L.BIS_UPGRADES:upper())
        up.rows = {}
        f.up = up

        local shown = {}
        for _, st in ipairs(Stats.LIST) do
            if st.group ~= "res" then shown[#shown + 1] = st end
        end
        for i, st in ipairs(shown) do
            local r = CreateFrame("Frame", nil, list)
            r:SetSize(330, 24)
            r:SetPoint("TOPLEFT", 0, -(i - 1) * 25)
            r.name = Kit.Text(r, "small", C.text)
            r.name:SetPoint("LEFT")
            r.name:SetWidth(130)
            r.name:SetText(st.label .. (st.pct and FDJ.Paint("dim", " (1%)") or ""))
            r.track = r:CreateTexture(nil, "ARTWORK")
            r.track:SetPoint("LEFT", 136, 0)
            r.track:SetSize(110, 4)
            r.track:SetColorTexture(RGB(C.field, 1))
            r.bar = r:CreateTexture(nil, "ARTWORK", nil, 1)
            r.bar:SetPoint("LEFT", r.track, "LEFT")
            r.bar:SetHeight(4)
            r.input = Kit.Input(r, 66, 22, "0", nil, function(self, text)
                Stats.SetWeight(st.id, tonumber(text) or 0, nil, f.spec)
                self:ClearFocus()
            end)
            r.input:SetPoint("RIGHT")
            r.input:SetJustifyH("CENTER")
            r.input:HookScript("OnEditFocusLost", function(self)
                local v = tonumber(self:GetText()) or 0
                local w = Stats.Weights(nil, f.spec)
                if v ~= (w[st.id] or 0) then Stats.SetWeight(st.id, v, nil, f.spec) end
            end)
            r.id = st.id
            f.rows[#f.rows + 1] = r
        end

        local function upgradeRow(i)
            local r = up.rows[i]
            if r then return r end
            r = CreateFrame("Button", nil, up)
            r:SetHeight(36)
            r:SetPoint("TOPLEFT", 0, -20 - (i - 1) * 40)
            r:SetPoint("RIGHT", up, "RIGHT")
            r.icon = r:CreateTexture(nil, "ARTWORK")
            r.icon:SetSize(30, 30)
            r.icon:SetPoint("LEFT")
            r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            r.name = Kit.Text(r, "small", C.white)
            r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, -2)
            r.name:SetPoint("RIGHT", -70, 0)
            r.slot = Kit.Text(r, "tiny", C.muted)
            r.slot:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -3)
            r.pct = Kit.Text(r, "small", C.good, "RIGHT")
            r.pct:SetPoint("RIGHT", 0, 0)
            r:SetScript("OnEnter", function(self) tipItem(self, self.itemID, nil, true) end)
            r:SetScript("OnLeave", Kit.HideTip)
            r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            r:SetScript("OnClick", function(self, button)
                if button == "RightButton" then f:Hide() return end
                if self.group then f:Hide() page:OpenPicker(self.group) end
            end)
            up.rows[i] = r
            return r
        end

        function f:Paint()
            local specs = Bis.Specs()
            self.spec = self.spec or Bis.SpecOf()
            for i, sp in ipairs(specs) do
                local b = self.specs[i]
                if not b then
                    b = Kit.Button(self, sp.name, nil, 24, nil, nil)
                    b:SetScript("OnClick", function() self.spec = b.key self:Paint() end)
                    self.specs[i] = b
                    if i == 1 then b:SetPoint("TOPLEFT", 16, -60) else b:SetPoint("LEFT", self.specs[i - 1], "RIGHT", 4, 0) end
                    b.icon = b:CreateTexture(nil, "ARTWORK")
                    b.icon:SetSize(16, 16)
                    b.icon:SetPoint("LEFT", 6, 0)
                    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
                    b.label:ClearAllPoints()
                    b.label:SetPoint("LEFT", b.icon, "RIGHT", 6, 0)
                    b:SetWidth(b.label:GetStringWidth() + 40)
                end
                b.key = sp.key
                b.icon:SetTexture(sp.icon)
                local on = sp.key == self.spec
                Kit.EdgeColor(b, on and C.accent or C.borderDim)
                b.label:SetTextColor(RGB(on and C.white or C.muted))
            end
            local w, custom = Stats.Weights(nil, self.spec)
            local name = ""
            for _, sp in ipairs(specs) do if sp.key == self.spec then name = sp.name end end
            self.sub:SetText(custom and L.BIS_WEIGHTS_CUSTOM:format(name) or L.BIS_WEIGHTS_DEFAULT:format(name))
            local top = 0
            for _, r in ipairs(self.rows) do
                local v = w[r.id] or 0
                if not Stats.BY_ID[r.id].pct and r.id ~= "DPS" then top = math.max(top, v) end
            end
            local topPct = 0
            for _, r in ipairs(self.rows) do
                if Stats.BY_ID[r.id].pct or r.id == "DPS" then topPct = math.max(topPct, w[r.id] or 0) end
            end
            for _, r in ipairs(self.rows) do
                local v = w[r.id] or 0
                local scale = (Stats.BY_ID[r.id].pct or r.id == "DPS") and topPct or top
                r.bar:SetWidth(math.max(1, 110 * (scale > 0 and math.min(1, v / scale) or 0)))
                r.bar:SetColorTexture(RGB(v > 0 and C.accent or C.dim, 0.9))
                if not r.input:HasFocus() then r.input:SetText(v ~= 0 and tostring(v) or "") end
            end

            local ups = {}
            for _, g in ipairs(Bis.GROUPS) do
                local list = Bis.Suggest.Ranked(g, { weights = w })
                local worn
                for _, slot in ipairs(g.slots) do
                    local id = GetInventoryItemID("player", slot)
                    local sc = id and Stats.ItemScore(id, w) or 0
                    if not worn or sc < worn then worn = sc end
                end

                local best, bestScore
                for i = 1, math.min(5, #list) do
                    local e = list[i]
                    local sc = Stats.ItemScore(e.id, w)
                    if sc and (not bestScore or sc > bestScore) then best, bestScore = e.id, sc end
                end
                if best and bestScore > (worn or 0) then
                    local gain = (worn or 0) > 0 and (bestScore - worn) / math.max(worn, bestScore * 0.25) or 4
                    ups[#ups + 1] = { id = best, g = g, gain = gain, worn = worn or 0, score = bestScore }
                end
            end
            table.sort(ups, function(a, b) return a.gain > b.gain end)
            for i = 1, math.max(#ups, #up.rows) do
                local e = ups[i]
                if e and i <= 10 then
                    local r = upgradeRow(i)
                    local name, qc = quality(e.id)
                    r.itemID, r.group = e.id, e.g
                    r.icon:SetTexture(C_Item.GetItemIconByID(e.id) or 134400)
                    r.name:SetText(name or L.LOADING)
                    r.name:SetTextColor(RGB(qc or C.text))
                    r.slot:SetText(Bis.Label(e.g))
                    r.pct:SetText((gainText(e.worn, e.score)))
                    r:Show()
                elseif up.rows[i] then
                    up.rows[i]:Hide()
                end
            end
            up.head:SetText((L.BIS_UPGRADES .. (#ups > 0 and ("  " .. #ups) or "")):upper())
        end
        FDJ:On("FDJ_BIS_WEIGHTS", function() if f:IsVisible() then f:Paint() end end)
        FDJ:On("FDJ_BIS_ITEMS", function()
            if f:IsVisible() then FDJ.Debounce("bisweights" .. (page.isPopout and "pop" or "page"), 0.5, function() f:Paint() end) end
        end)
        f:Hide()
        return f
    end

    function page:OpenWeights()
        weightsFrame = weightsFrame or buildWeights()
        weightsFrame.spec = Bis.SpecOf()
        if page.ClosePicker then page:ClosePicker() end
        if statsFrame then statsFrame:Hide() end
        weightsFrame:Show()
        weightsFrame:Paint()
    end

    local picker
    local function buildPicker()
        local f = card(view)
        f:SetPoint("TOPLEFT", right, "TOPLEFT")
        f:SetPoint("BOTTOMRIGHT", right, "BOTTOMRIGHT")
        f:SetFrameLevel(right:GetFrameLevel() + 20)
        f:EnableMouse(true)
        Kit.Fill(f, C.frame, 0.97, "BACKGROUND", -1)

        f.slotIcon = f:CreateTexture(nil, "ARTWORK")
        f.slotIcon:SetSize(30, 30)
        f.slotIcon:SetPoint("TOPLEFT", 14, -12)
        f.slotIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        f.title = Kit.Text(f, "large", C.white)
        f.title:SetPoint("TOPLEFT", f.slotIcon, "TOPRIGHT", 10, 0)
        f.sub = Kit.Text(f, "tiny", C.muted)
        f.sub:SetPoint("TOPLEFT", f.title, "BOTTOMLEFT", 0, -4)
        f.close = Kit.CloseButton(f, function() f:Hide() end)
        f.close:SetPoint("TOPRIGHT", -6, -6)
        backable(f, f.slotIcon)
        f.title:ClearAllPoints()
        f.title:SetPoint("TOPLEFT", f.slotIcon, "TOPRIGHT", 10, 0)

        f.mineHead = Kit.Text(f, "tiny", C.accent)
        f.mineHead:SetPoint("TOPLEFT", 14, -56)
        f.mineHead:SetText(L.BIS_YOUR_PICKS:upper())
        f.mine = {}
        local function mineRow(i)
            local r = CreateFrame("Button", nil, f)
            r:SetHeight(32)
            r:SetPoint("TOPLEFT", 14, -72 - (i - 1) * 34)
            r:SetPoint("RIGHT", f, "RIGHT", -14, 0)
            r.bg = r:CreateTexture(nil, "BACKGROUND")
            r.bg:SetAllPoints()
            r.bg:SetColorTexture(RGB(C.panel, 0.7))
            r.num = Kit.Text(r, "small", C.dim, "CENTER")
            r.num:SetPoint("LEFT", 0, 0)
            r.num:SetWidth(22)
            r.icon = r:CreateTexture(nil, "ARTWORK")
            r.icon:SetSize(26, 26)
            r.icon:SetPoint("LEFT", 24, 0)
            r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            r.name = Kit.Text(r, "small", C.white)
            r.name:SetPoint("LEFT", r.icon, "RIGHT", 8, 0)
            r.name:SetPoint("RIGHT", -150, 0)
            r.state = Kit.Text(r, "tiny", C.muted, "RIGHT")
            r.state:SetPoint("RIGHT", -64, 0)
            r.up = Kit.IconButton(r, "fc:icon-chevron-up", 24, L.BIS_MOVE_UP, function()
                Bis.Promote(r.itemID, state.viewKey)
            end)
            r.up:SetPoint("RIGHT", -30, 0)
            r.remove = Kit.IconButton(r, "fc:icon-minus", 24, L.BIS_REMOVE, function()
                Kit.HideTip()
                Bis.Remove(r.itemID, state.viewKey)
            end)
            r.remove:SetPoint("RIGHT", 0, 0)
            r:SetScript("OnEnter", function(self) if self.itemID then tipItem(self, self.itemID) end end)
            r:SetScript("OnLeave", Kit.HideTip)
            r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            r:SetScript("OnClick", function(self, button)
                if button == "RightButton" then f:Hide() return end
                if IsShiftKeyDown() then
                    local _, link = C_Item.GetItemInfo(self.itemID)
                    if link then HandleModifiedItemClick(link) end
                else
                    openBoss(self.itemID)
                end
            end)
            f.mine[i] = r
            return r
        end
        f.mineEmpty = Kit.Text(f, "small", C.dim)
        f.mineEmpty:SetPoint("TOPLEFT", 14, -76)
        f.mineEmpty:SetText(L.BIS_PICKER_NONE)

        f.search = Kit.Input(f, 260, 28, L.BIS_SEARCH, function(_, text)
            f.query = (text or ""):lower()
            f:Fill()
        end, function(self, text)
            local id = FDJ.ItemFromLink(text) or tonumber((text or ""):match("^%s*(%d+)%s*$"))
            if id then
                Bis.Add(id, state.viewKey)
                self:SetText("")
            end
        end, "fc:icon-search")
        f.range = Kit.Segmented(f, { { "level", L.BIS_RANGE_LEVEL }, { "all", L.BIS_RANGE_ALL } }, function(key)
            f.all = key == "all"
            f:Fill()
        end)
        f.range:SetSize(190, 28)
        f.listHead = Kit.Text(f, "tiny", C.accent)
        f.list = Kit.Scroller(f)
        f.list:SetPoint("BOTTOMRIGHT", -8, 8)
        f.cands = Kit.Pool(function()
            local r = CreateFrame("Button", nil, f.list.content)
            r:SetHeight(40)
            r:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            r.bg = r:CreateTexture(nil, "BACKGROUND")
            r.bg:SetAllPoints()
            r.hl = r:CreateTexture(nil, "HIGHLIGHT")
            r.hl:SetAllPoints()
            r.hl:SetColorTexture(1, 1, 1, 0.05)
            r.icon = r:CreateTexture(nil, "ARTWORK")
            r.icon:SetSize(30, 30)
            r.icon:SetPoint("LEFT", 8, 0)
            r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
            r.edge = CreateFrame("Frame", nil, r)
            r.edge:SetAllPoints(r.icon)
            Kit.Edge(r.edge, C.borderDim)
            r.name = Kit.Text(r, "small", C.white)
            r.name:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 10, -1)
            r.name:SetPoint("RIGHT", -110, 0)
            r.meta = Kit.Text(r, "tiny", C.muted)
            r.meta:SetPoint("TOPLEFT", r.name, "BOTTOMLEFT", 0, -4)
            r.meta:SetPoint("RIGHT", -110, 0)
            r.pct = Kit.Text(r, "small", C.good, "RIGHT")
            r.pct:SetPoint("RIGHT", -40, 5)
            r.pct:SetWidth(64)
            r.track = r:CreateTexture(nil, "ARTWORK")
            r.track:SetSize(60, 3)
            r.track:SetPoint("TOPRIGHT", r.pct, "BOTTOMRIGHT", 0, -3)
            r.track:SetColorTexture(RGB(C.field, 1))
            r.bar = r:CreateTexture(nil, "ARTWORK", nil, 1)
            r.bar:SetHeight(4)
            r.bar:SetPoint("LEFT", r.track, "LEFT")
            r.added = r:CreateTexture(nil, "OVERLAY")
            r.added:SetSize(16, 16)
            r.added:SetPoint("RIGHT", -12, 0)
            r:SetScript("OnEnter", function(self)
                tipItem(self, self.itemID, self.picked and L.BIS_CAND_REMOVE or L.BIS_CAND_ADD)
            end)
            r:SetScript("OnLeave", Kit.HideTip)
            r:SetScript("OnClick", function(self, button)
                if IsShiftKeyDown() then
                    local _, link = C_Item.GetItemInfo(self.itemID)
                    if link then HandleModifiedItemClick(link) end
                    return
                end
                if button == "RightButton" then
                    f:Hide()
                elseif IsControlKeyDown() then
                    openBoss(self.itemID)
                elseif self.picked then
                    Bis.Remove(self.itemID, state.viewKey)
                else
                    Bis.Add(self.itemID, state.viewKey, true)
                end
            end)
            return r
        end)

        function f:Fill()
            local g = self.group
            if not g then return end
            local picks = Bis.Picks(g, state.viewKey)
            local isMine = mine()

            local shown = math.min(#picks, 6)
            for i = 1, math.max(shown, #self.mine) do
                local r = self.mine[i] or (i <= shown and mineRow(i))
                if r then
                    if i <= shown then
                        local id = picks[i]
                        r.itemID = id
                        r.num:SetText(i)
                        r.num:SetTextColor(RGB(i <= Bis.Wants(g) and C.amber or C.dim))
                        r.icon:SetTexture(C_Item.GetItemIconByID(id) or 134400)
                        local name, qc = quality(id)
                        r.name:SetText(name or L.LOADING)
                        r.name:SetTextColor(RGB(qc or C.text))
                        local st = isMine and Bis.State(g, id)
                        r.state:SetText(st == "equipped" and FDJ.Paint("good", L.BIS_STATUS_WORN) or (st == "owned" and FDJ.Paint("amber", L.BIS_STATUS_BAGS) or ""))
                        r.up:SetShown(i > 1)
                        r:Show()
                    else
                        r:Hide()
                    end
                end
            end
            self.mineEmpty:SetShown(#picks == 0)
            local top = -72 - math.max(1, shown) * 34 - 10
            self.search:ClearAllPoints()
            self.search:SetPoint("TOPLEFT", 14, top)
            self.range:ClearAllPoints()
            self.range:SetPoint("LEFT", self.search, "RIGHT", 8, 0)
            self.listHead:ClearAllPoints()
            self.listHead:SetPoint("TOPLEFT", self.search, "BOTTOMLEFT", 0, -12)
            self.list:ClearAllPoints()
            self.list:SetPoint("TOPLEFT", self.listHead, "BOTTOMLEFT", -6, -6)
            self.list:SetPoint("BOTTOMRIGHT", -8, 8)

            local pickedSet = {}
            for _, id in ipairs(picks) do pickedSet[id] = true end
            local ownerData = mine() and FDJ.char or FDJ.db.chars[state.viewKey] or FDJ.char
            local ownerSpec = Bis.SpecOf(state.viewKey)
            local weights = Bis.Stats.Weights(ownerData.class, ownerSpec)
            local list, waiting, nextLevel = Bis.Suggest.Ranked(g, { any = self.all, class = ownerData.class, weights = weights })
            local q = self.query or ""
            local worn
            for _, slot in ipairs(g.slots) do
                local id = GetInventoryItemID("player", slot)
                local sc = id and Bis.Stats.ItemScore(id, weights) or 0
                if not worn or sc < worn then worn = sc end
            end
            worn = worn or 0
            local compare = mine()
            self.cands:Reset()
            local y, n = 0, 0
            local width = math.max(200, self.list:GetWidth() - 10)
            self.list.content:SetWidth(width)
            for _, e in ipairs(list) do
                if n >= 60 then break end
                local name, qc = quality(e.id)
                local hit = q == "" or tostring(e.id) == q or (name and name:lower():find(q, 1, true))
                if hit then
                    n = n + 1
                    local r = self.cands:Get()
                    r:SetPoint("TOPLEFT", 0, -y)
                    r:SetPoint("RIGHT", self.list.content, "RIGHT")
                    r.itemID = e.id
                    r.picked = pickedSet[e.id]
                    r.bg:SetColorTexture(RGB(r.picked and C.good or C.panel, r.picked and 0.08 or (n % 2 == 0 and 0.3 or 0.55)))
                    r.icon:SetTexture(C_Item.GetItemIconByID(e.id) or 134400)
                    Kit.EdgeColor(r.edge, qc or C.borderDim, 0.95)
                    r.name:SetText(name or L.LOADING)
                    r.name:SetTextColor(RGB(qc or C.text))
                    local boss, odds = Bis.Source(e.id)
                    local quest = not boss and Bis.QuestFor(e.id)
                    local tooHigh = e.req > FDJ.Level()
                    local lvl = (tooHigh and FDJ.Paint("amber", L.BIS_REQ:format(e.req)) or L.BIS_REQ:format(e.req))
                    r.meta:SetText(L.BIS_ILVL:format(e.ilvl) .. "  ·  " .. lvl .. (boss and ("  ·  " .. FDJ.DungeonTitle(boss.dungeon) .. FDJ.Paint("dim", " - " .. boss.n .. (odds and (" " .. odds .. "%") or ""))) or (quest and ("  ·  " .. L.BIS_FROM_QUEST:format(quest.t))) or ""))
                    local itemScore = Bis.Stats.ItemScore(e.id, weights) or 0
                    local gain = worn > 0 and (itemScore - worn) / math.max(worn, itemScore * 0.25) or (itemScore > 0 and 1 or 0)
                    if compare then
                        local text, color = gainText(worn, itemScore)
                        r.pct:SetText(text ~= "" and text or "=")
                        r.pct:SetTextColor(RGB(color and C[color] or C.muted))
                    else
                        r.pct:SetText("")
                        gain = 0
                    end
                    r.bar:SetWidth(math.max(2, 60 * math.max(0, math.min(1, gain))))
                    r.bar:SetColorTexture(RGB(gain > 0 and C.good or C.muted, 0.9))
                    if r.picked then
                        r.added:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
                    else
                        r.added:SetTexture(FDJ.Glyph("fc:icon-plus"))
                        r.added:SetVertexColor(RGB(C.muted))
                    end
                    y = y + 42
                end
            end
            self.list:SetContentHeight(y)
            local head = self.all and L.BIS_CANDS_ALL or L.BIS_CANDS_LEVEL:format(FDJ.Level())
            if waiting > 0 then head = head .. FDJ.Paint("dim", "   " .. L.BIS_LOADING_N:format(waiting)) end
            if n == 0 and waiting == 0 then
                head = head .. FDJ.Paint("dim", "   " .. (nextLevel and L.BIS_CANDS_NEXT:format(nextLevel) or L.BIS_CANDS_NONE))
            end
            self.listHead:SetText(head:upper())
        end

        f:SetScript("OnHide", function() f.group = nil end)
        FDJ:On("FDJ_WISHES", function() if f:IsVisible() then f:Fill() end end)
        FDJ:On("FDJ_BIS_ITEMS", function()
            if f:IsVisible() then FDJ.Debounce("bispicker" .. (page.isPopout and "pop" or "page"), 0.4, function() f:Fill() end) end
        end)
        f:Hide()
        return f
    end

    function page:ClosePicker()
        if picker then picker:Hide() end
    end

    function page:OpenPicker(group)
        if not group then return end
        if weightsFrame then weightsFrame:Hide() end
        if statsFrame then statsFrame:Hide() end
        picker = picker or buildPicker()
        picker.group = group
        picker.query = ""
        picker.search:SetText("")
        picker.all = false
        picker.range:Select("level", true)
        picker.title:SetText(Bis.Label(group))
        picker.slotIcon:SetTexture(slotTexture(group.slots[1]))
        picker.sub:SetText(mine() and "" or L.BIS_ALT)
        picker:Show()
        picker:Fill()
    end

    local function slotTex(slot)
        local name = SLOT_NAMES[slot]
        if name and GetInventorySlotInfo then
            local ok, _, tex = pcall(GetInventorySlotInfo, name)
            if ok and tex then return tex end
        end
        return 134400
    end

    function paintTile(t, g, id, slot, isMine)
        t.itemID = id
        t.slot:SetTexture(slotTex(slot))
        if id then
            t.icon:SetTexture(C_Item.GetItemIconByID(id) or 134400)
            t.icon:Show()
            t.slot:Hide()
            local _, qc = quality(id)
            Kit.EdgeColor(t, qc or C.borderDim, qc and 0.95 or 1)
            local st = isMine and Bis.State(g, id)
            if st == "equipped" then
                t.check:SetTexture("Interface\\RaidFrame\\ReadyCheck-Ready")
                t.check:Show()
            elseif st == "owned" then
                t.check:SetTexture("Interface\\Buttons\\Button-Backpack-Up")
                t.check:Show()
            else
                t.check:Hide()
            end
        else
            t.icon:Hide()
            t.slot:Show()
            Kit.EdgeColor(t, C.borderDim)
            t.check:Hide()
        end
    end

    local dressed
    function page:Dress(force)
        if not model:IsVisible() then return end
        local bis = state.look == "bis" and mine()
        local wear = {}
        for _, g in ipairs(Bis.GROUPS) do
            local picks = Bis.Picks(g)
            for i, slot in ipairs(g.slots) do
                local id = (bis and picks[i]) or GetInventoryItemID("player", slot)
                if id and slot ~= 18 then wear[#wear + 1] = { slot, id } end
            end
        end
        local parts = {}
        for i, w in ipairs(wear) do parts[i] = w[1] .. ":" .. w[2] end
        table.sort(parts)
        local sig = (bis and "bis|" or "now|") .. table.concat(parts, ",")
        if sig == dressed and not force then return end
        dressed = sig
        pcall(model.SetUnit, model, "player")
        if not bis then return end
        pcall(model.Undress, model)
        for _, w in ipairs(wear) do pcall(model.TryOn, model, "item:" .. w[2], HAND[w[1]]) end
    end

    function page:Refresh()
        if not view:IsVisible() then return end
        local isMine = mine()
        local owner = isMine and FDJ.char or FDJ.db.chars[state.viewKey] or FDJ.char
        local listName = Bis.ActiveName(state.viewKey)
        listBtn:SetLabel(FDJ.Paint(FDJ.Party.ClassColor(owner.class), owner.name or "?") .. (isMine and "" or FDJ.Paint("dim", "  " .. L.BIS_VIEWING)))
        local alone = #otherChars() == 0
        caret:SetShown(not alone)
        listBtn.tip = alone and L.BIS_CHARACTERS or nil
        listBtn.tipBody = alone and L.BIS_CHARACTERS_NONE or nil

        nameText:SetText(FDJ.Paint(FDJ.Party.ClassColor(owner.class), owner.name or "?"))
        if isMine then
            local spec = FojjiCore and FojjiCore.GetSpec and FojjiCore.GetSpec()
            local cls = UnitClass and UnitClass("player") or ""
            infoText:SetText(L.LEVEL .. " " .. FDJ.Level() .. "  " .. cls .. (spec and spec.name and ("  ·  " .. spec.name) or ""))
        else
            infoText:SetText(L.BIS_ALT)
        end

        local d, n, _, far = Bis.RunNext()
        if isMine and d then
            if dungeonArt(run.art, d) then run.art:Show() else run.art:Hide() end
            run.name:SetText(FDJ.DungeonTitle(d))
            run.head:SetText((far and L.BIS_RUN_LATER or L.BIS_RUN_HEAD):upper())
            run.meta:SetText(FDJ.Paint(FDJ.RangeColor(d), d.range[1] .. "-" .. d.range[2]) .. FDJ.Paint("muted", "  ·  " .. L.BIS_RUN_COUNT:format(n)))
            run.arrow:Show()
            run:Enable()
        else
            run.art:Hide()
            run.name:SetText(FDJ.Paint("dim", L.BIS_RUN_EMPTY))
            run.meta:SetText(FDJ.Paint("dim", L.BIS_RUN_NONE))
            run.arrow:Hide()
            run:Disable()
        end

        for slot, b in pairs(slotButtons) do
            local g, index = groupOfSlot(slot)
            b.group = g
            local picks = g and Bis.Picks(g, state.viewKey) or {}
            paintTile(b, g, picks[index or 1], slot, isMine)
        end

        paintSpecs()
        page:PaintTrack()
        page:PaintList()
        page:PaintStats()
        self:Dress()
    end

    later = function() FDJ.Debounce("bispage" .. (page.isPopout and "pop" or "page"), 0.3, function() page:Refresh() end) end
    FDJ:On("FDJ_WISHES", function() if view:IsVisible() then later() end end)
    FDJ:On("FDJ_BIS_ITEMS", function() if view:IsVisible() then later() end end)
    FDJ:On("FDJ_BIS_WEIGHTS", function() if view:IsVisible() then later() end end)
    FDJ:On("BAG_UPDATE_DELAYED", function() if view:IsVisible() then later() end end)
    FDJ:On("GET_ITEM_INFO_RECEIVED", function(itemID)
        if asked[itemID] and view:IsVisible() then later() end
    end)
    view:SetScript("OnShow", function()
        look:Select(state.look, true)
        dressed = nil
        page:Refresh()
    end)
    view:SetScript("OnSizeChanged", function() if view:IsVisible() then later() end end)
end

buildSettings = function(parent)
    local f = CreateFrame("Frame", nil, parent)
    local o = Bis.Options()
    local y = 6
    local function head(text)
        local t = Kit.Text(f, "tiny", C.accent)
        t:SetPoint("TOPLEFT", 0, -y)
        t:SetText(text:upper())
        local line = f:CreateTexture(nil, "BORDER")
        line:SetPoint("TOPLEFT", 0, -(y + 14))
        line:SetPoint("TOPRIGHT", 0, -(y + 14))
        line:SetHeight(1)
        Kit.Paint(line, C.borderDim)
        y = y + 24
    end
    local checks = {}
    local function check(key, text, tip, getter, setter)
        local b = Kit.Check(f, text, getter or function() return Bis.Options()[key] end, setter or function(v) Bis.Set(key, v) end, tip)
        b:SetPoint("TOPLEFT", 0, -y)
        checks[#checks + 1] = b
        y = y + 28
        return b
    end

    head(L.BIS_TITLE)
    check("enabled", L.BIS_OPT_DISABLE, L.BIS_OPT_DISABLE_TIP,
        function() return Bis.Options().enabled == false end,
        function(v) Bis.Set("enabled", not v) end)
    y = y + 10

    head(L.BIS_OPT_FEATURES)
    check("tooltip", L.BIS_OPT_TOOLTIP, L.BIS_OPT_TOOLTIP_TIP)
    check("alerts", L.BIS_OPT_ALERTS, L.BIS_OPT_ALERTS_TIP)
    check("altClick", L.BIS_OPT_ALTCLICK, L.BIS_OPT_ALTCLICK_TIP)
    check("gearScore", L.BIS_OPT_GS, L.BIS_OPT_GS_TIP)
    check("autoSuggest", L.BIS_OPT_AUTOFILL, L.BIS_OPT_AUTOFILL_TIP)
    y = y + 10

    head(L.BIS_OPT_SHORTCUT)
    local label = Kit.Text(f, "small", C.text)
    label:SetPoint("TOPLEFT", 0, -(y + 6))
    label:SetText(L.BIS_OPT_KEY)
    local key = Kit.Button(f, "", 150, 26)
    key:SetPoint("LEFT", label, "RIGHT", 12, 0)
    local hint = Kit.Text(f, "tiny", C.dim)
    hint:SetPoint("LEFT", key, "RIGHT", 10, 0)
    local function showKey()
        local k = Bis.Options().key or ""
        key:SetLabel(key.waiting and L.BIS_KEY_PRESS or (k ~= "" and (GetBindingText and GetBindingText(k) or k) or L.BIS_KEY_NONE))
        hint:SetText(key.waiting and L.BIS_KEY_WAIT or L.BIS_KEY_CHANGE)
    end
    key:SetScript("OnClick", function(self)
        self.waiting = true
        self:EnableKeyboard(true)
        showKey()
    end)
    key:SetScript("OnKeyDown", function(self, k)
        if not self.waiting then return end
        if k:match("SHIFT$") or k:match("CTRL$") or k:match("ALT$") then return end
        self.waiting = nil
        self:EnableKeyboard(false)
        if k ~= "ESCAPE" then
            if k == "BACKSPACE" or k == "DELETE" then
                k = ""
            else
                k = (IsAltKeyDown() and "ALT-" or "") .. (IsControlKeyDown() and "CTRL-" or "") .. (IsShiftKeyDown() and "SHIFT-" or "") .. k
            end
            Bis.Set("key", k)
        end
        showKey()
    end)
    key:EnableKeyboard(false)
    y = y + 40
    local pop = Kit.Button(f, L.BIS_POPOUT, nil, 26, function() Bis.TogglePopout() end, nil, "fc:icon-export")
    pop:SetPoint("TOPLEFT", 0, -y)
    y = y + 44

    head(L.BIS_OPT_DATA)
    local clear = Kit.Button(f, L.BIS_CLEAR, nil, 26, function()
        Kit.Confirm(L.BIS_CLEAR_Q, function()
            wipe(Bis.Store())
            FDJ:Emit("FDJ_WISHES")
        end)
    end)
    clear:SetPoint("TOPLEFT", 0, -y)

    f:SetScript("OnShow", function()
        for _, b in ipairs(checks) do b:Sync() end
        showKey()
    end)
    return f
end

function Addon.CreateBisPage(page)
    buildManager(page, -54, 0)
end

local popout
function Bis.TogglePopout()
    if not popout then
        popout = Kit.Window("FojjiCoreBisWindow", L.BIS_TITLE, 1140, 780)
        popout.isPopout = true
        popout:SetFrameStrata("MEDIUM")
        local icon = popout.head:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", 14, 0)
        icon:SetTexture(FDJ.icon)
        popout.title:ClearAllPoints()
        popout.title:SetPoint("LEFT", icon, "RIGHT", 10, 0)
        local metal = popout.head:CreateTexture(nil, "BACKGROUND", nil, 2)
        metal:SetAllPoints()
        metal:SetTexture(CORE .. "header-metal")
        metal:SetAlpha(0.35)
        local wash = Kit.Gradient(popout.head, "HORIZONTAL", C.accent, 0.22, 0, "BACKGROUND", 3)
        wash:SetPoint("TOPLEFT")
        wash:SetPoint("BOTTOMLEFT")
        wash:SetWidth(320)
        local topRule = popout:CreateTexture(nil, "OVERLAY")
        topRule:SetPoint("TOPLEFT", 1, -1)
        topRule:SetPoint("TOPRIGHT", -1, -1)
        topRule:SetHeight(2)
        Kit.Paint(topRule, C.accent, 0.9)
        local headRule = popout.head:CreateTexture(nil, "OVERLAY")
        headRule:SetPoint("BOTTOMLEFT")
        headRule:SetPoint("BOTTOMRIGHT")
        headRule:SetHeight(1)
        Kit.Paint(headRule, C.accent, 0.35)
        Kit.EdgeColor(popout, C.accent, 0.45)
        local pos = FDJ.db and FDJ.db.window
        if pos and pos.bisW then popout:SetSize(math.max(pos.bisW, 1000), math.max(pos.bisH, 700)) end
        if pos and pos.bisX then
            popout:ClearAllPoints()
            popout:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", pos.bisX, pos.bisY)
        end
        function popout:OnMoved()
            if pos then pos.bisX, pos.bisY = self:GetLeft(), self:GetTop() end
        end
        Kit.Resizable(popout, 1000, 700, function(self)
            if pos then
                pos.bisW, pos.bisH = self:GetWidth(), self:GetHeight()
                pos.bisX, pos.bisY = self:GetLeft(), self:GetTop()
            end
        end)
        buildManager(popout, -48, 12)
    end
    popout:SetShown(not popout:IsShown())
    if popout:IsShown() then popout:Raise() end
end
