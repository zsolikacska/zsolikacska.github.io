local _, Addon = ...
local ForeverAuras = Addon.AuraAPI
local ForeverAurasSaved = Addon.AuraSaved
local SharedMedia = LibStub("LibSharedMedia-3.0")

FojjiCore = FojjiCore or {}
FojjiCore_Version = "3.1.4"

FojjiCore.fontPatchGroups = {

    "Fojji - Class Pack Anchors [Forever]",
    "Fojji - Class Pack Anchors [Forever] 1440p",
    "Fojji - Class Pack Anchors [Forever] 1080p",
    "Fojji - Druid UI [Forever]",
    "Fojji - Hunter UI [Forever]",
    "Fojji - Mage UI [Forever]",
    "Fojji - Paladin UI [Forever]",
    "Fojji - Priest UI [Forever]",
    "Fojji - Rogue UI [Forever]",
    "Fojji - Shaman UI [Forever]",
    "Fojji - Warlock UI [Forever]",
    "Fojji - Warrior UI [Forever]",

    "Fojji - Item & Trinket Tracker",
    "Fojji - Pull & Break Timers",
    "Fojji - Buff Tracker [Forever]",
    "Fojji - Debuff Tracker [Forever]",
    "Fojji - Campfire Guild Helper [Forever]",
    "Fojji - Cooldown Pulse [Forever]",
    "Fojji - Equipment Manager [Forever]",
    "Fojji - Experience Bar [Forever]",
    "Fojji - Friendly XP Tracker [Forever]",
    "Fojji - Incoming Combat Text [Forever]",
    "Fojji - Mage Vending Machine [Forever]",
    "Fojji - Object Highlight [Forever]",
    "Fojji - Sunder Armor on Nameplates",
    "Fojji - Target Name on Nameplate",
    "Fojji - Threat on Nameplates [Forever]",
    "Fojji - Town Consumes Helper [Forever]",
    "Fojji - Raid Watch [Forever]",
    "Fojji - Cast Times [Forever]",
    "Fojji - Character Stats [Forever]",
    "NCT - Multi-Column Template",
    "Numen - Cooldown Tracker [Forever]",

    "Fojji - Hyjal Raiding Pack [Forever]",
    "Fojji - The Venomous Abyss [Forever]",
    "Fojji - Raid Demo [Forever]",
    "Fojji - Raid Pack Anchors [Forever]",

    "Fojji - [Forever] Hyjal Summit",
    "Fojji - [Forever] Hyjal",

    "Fojji - Druid UI [TBC]",
    "Fojji - Hunter UI [TBC]",
    "Fojji - Mage UI [TBC]",
    "Fojji - Paladin UI [TBC]",
    "Fojji - Priest UI [TBC]",
    "Fojji - Rogue UI [TBC]",
    "Fojji - Shaman UI [TBC]",
    "Fojji - Warlock UI [TBC]",
    "Fojji - Warrior UI [TBC]",

    "Fojji - [T4] Raiding Pack [TBC]",
    "Fojji - [T5] Raid Frames",
    "Fojji - [T5] Raiding Pack",
    "Fojji - [T6] Black Temple [Part 1]",
    "Fojji - [T6] Black Temple [Part 2]",
    "Fojji - [T6] Mount Hyjal",
    "Fojji - [Forever] Mount Hyjal",
    "Fojji - [Midnight S2] The Venomous Abyss",
    "Fojji - Raid Demo",
    "Fojji - Raid Assignments [Forever]",
    "Fojji - [T6] Raid Frames",
    "Fojji - [T6] Raid Leader",
    "Fojji - Karazhan [TBC]",
    "Fojji - Karazhan [TBC][Raid Frames]",
    "Fojji - Raid Pack Anchors [Classic]",

    "Fojji - Dungeon Pack [TBC][P1]",
    "Fojji - Dungeon Pack [TBC][P2]",
    "Fojji - Dungeon Pack [TBC][Party Frames]",

    "Fojji - API Role [TBC]",
    "Fojji - Essentials [TBC]",
    "Numen - Core [TBC]",
    "Numen - Cooldown Tracker [TBC]",

    "Fojji - Arcane Bomb Suite [TBC]",
    "Fojji - AutoMarker [TBC]",
    "Fojji - Boss Kill Times [TBC]",
    "Fojji - Buff Tracker [TBC]",
    "Fojji - Consumables [TBC]",
    "Fojji - Cooldown Pulse [TBC]",
    "Fojji - Debuff Tracker [TBC]",
    "Fojji - External Aura Range [TBC]",
    "Fojji - Fatal Attraction GPS",
    "Fojji - Gear Checker [TBC]",
    "Fojji - Healer Mana Pot Carry [TBC]",
    "Fojji - Healer Tracker [TBC]",
    "Fojji - Incoming Heal Casts [TBC]",
    "Fojji - Item & Trinket Tracker [TBC]",
    "Fojji - JC Neck Tracker [TBC]",
    "Fojji - Pyromaniac [TBC]",
    "Fojji - Raid Leader Tools [TBC]",
    "Fojji - Raid Notes [TBC]",
    "Fojji - Raid Watch [TBC] [Zippy's Edit]",
    "Fojji - Reminder Pop-ups [TBC]",
    "Fojji - Target Swing Timer [TBC]",
    "Fojji - Taunt Alerter [TBC]",
    "Fojji - TBC Boss Frames [Jeyp's Edit]",
    "Fojji - Threat Assist",
    "Fojji - Town Consumes Helper [TBC]",
    "Fojji - WF_STATUS [TBC]",
    "Fojji - Who Pulled [TBC]",
    "Fojji - Pull & Break Timers",
}

local SOUND_CHANNELS = {
    Master = true,
    SFX = true,
    Music = true,
    Ambience = true,
    Dialog = true,
}

local function getFirstVoiceID()
    local voices = C_VoiceChat.GetTtsVoices() or {}
    return voices[1] and voices[1].voiceID
end

local function getSoundChannel()
    local DB = FojjiCoreDB
    local channel = DB and DB.ttsSoundChannel or "Master"

    if channel == "Sound Effects" then
        channel = "SFX"
    end

    if not SOUND_CHANNELS[channel] then
        channel = "Master"
    end

    return channel
end

local function getVoicePackFile(text)
    local DB = FojjiCoreDB

    if not DB or DB.ttsVoiceType ~= "custom" then
        return
    end

    if DB.ttsRandomFavorites then
        local favorites = {}

        for _,name in ipairs(FojjiCore.voicePackOrder or {}) do
            local pack = FojjiCore.voicePacks and FojjiCore.voicePacks[name]

            if DB.ttsVoiceFavorites and DB.ttsVoiceFavorites[name] and pack and pack[text] then
                favorites[#favorites+1] = name
            end
        end

        if #favorites == 0 then
            return
        end

        local name = favorites[math.random(#favorites)]
        return FojjiCore.voicePacks[name][text]
    end

    local pack = FojjiCore.voicePacks and FojjiCore.voicePacks[DB.ttsVoicePack]
    return pack and pack[text]
end

function FojjiCore:GetVoiceLineFile(text)
    if not text or text == "" then return nil end
    return getVoicePackFile(text)
end

function FojjiCore:ApplyTTSSettings()
    local DB = FojjiCoreDB

    if not DB then
        return
    end

    _G.FJITTS_SFX_VOLUME = DB.ttsVolume
    _G.FJITTS_SFX_RATE = DB.ttsRate
    _G.FJITTS_SFX_VOICEID = DB.ttsVoiceID
end

function FojjiCore:Speak(text)
    local DB = FojjiCoreDB

    if not DB or DB.disableTTS or not text or text == "" then
        return false
    end

    if DB.ttsVoiceType == "custom" then
        local file = getVoicePackFile(text)

        if file then
            local willPlay = PlaySoundFile(file,getSoundChannel())

            if willPlay then
                return true
            end
        end

        local voiceID = DB.ttsVoiceID or getFirstVoiceID()

        if not voiceID then
            return false
        end

        C_VoiceChat.SpeakText(voiceID,text,DB.ttsRate,DB.ttsVolume,true)
        return true
    end

    local voiceID = DB.ttsVoiceID or getFirstVoiceID()

    if not voiceID then
        return false
    end

    C_VoiceChat.SpeakText(voiceID,text,DB.ttsRate,DB.ttsVolume,true)
    return true
end

function FojjiCore:GetFontFromAura(auraName)
    local data = ForeverAuras.GetData(auraName)

    if data and data.config and data.config.option and data.config.option.font then
        return SharedMedia:Fetch("font",data.config.option.font)
    end
end

function FojjiCore:ApplyFontToRegion(region,fontPath)
    if not region or not fontPath then
        return
    end

    for _,subRegion in ipairs(region.subRegions or {}) do
        if subRegion.type == "subtext" then
            local _,size,flags = subRegion.text:GetFont()
            subRegion.text:SetFont(fontPath,size,flags)
        end
    end
end

function FojjiCore:ApplyFontToGroup(activeRegions,fontPath)
    if not fontPath then
        return
    end

    for _,regionData in ipairs(activeRegions or {}) do
        local region = regionData.region
        self:ApplyFontToRegion(region,fontPath)
    end
end

function FojjiCore:FindAuraName(name)
    if ForeverAuras.GetData(name) then return name end
    local want = name:lower():gsub("%s+", "")
    local displays = ForeverAurasSaved and ForeverAurasSaved.displays
    if displays then
        for id in pairs(displays) do
            if type(id) == "string" and id:lower():gsub("%s+", "") == want then return id end
        end
    end
end

local function patchOne(id, fontName)
    local saved = ForeverAurasSaved and ForeverAurasSaved.displays and ForeverAurasSaved.displays[id]
    if not saved then return end
    if saved.regionType == "text" then saved.font = fontName end
    if saved.subRegions then
        for _,sub in ipairs(saved.subRegions) do
            if sub.type == "subtext" then sub.text_font = fontName end
        end
    end
end

function FojjiCore:PatchFontForGroup(groupName,fontName,isRecursive)
    groupName = self:FindAuraName(groupName) or groupName
    local groupData = ForeverAuras.GetData(groupName)

    if not groupData then
        return
    end
    if not groupData.controlledChildren then
        patchOne(groupName, fontName)
        return
    end

    for _,childName in ipairs(groupData.controlledChildren) do
        local childData = ForeverAuras.GetData(childName)

        if childData and (childData.regionType == "group" or childData.regionType == "dynamicgroup") and childData.controlledChildren then
            self:PatchFontForGroup(childName,fontName,true)
        else
            local saved = ForeverAurasSaved and ForeverAurasSaved.displays and ForeverAurasSaved.displays[childName]

            if saved then
                if saved.regionType == "text" then
                    saved.font = fontName
                end

                if saved.subRegions then
                    for _,sub in ipairs(saved.subRegions) do
                        if sub.type == "subtext" then
                            sub.text_font = fontName
                        end
                    end
                end
            end
        end
    end

    if not isRecursive then
        Addon.Print(string.format("Fonts patched for group: |cff66b3ff%s|r",groupName))
        Addon.Print("Type |cff66b3ff/reload|r to apply font changes.")
    end
end

function FojjiCore:PatchFontForAll(fontName)
    if not fontName or not ForeverAuras then
        return
    end

    local patched = 0

    for _,groupName in ipairs(self.fontPatchGroups or {}) do
        local found = self:FindAuraName(groupName)

        if found then
            self:PatchFontForGroup(found,fontName,true)
            patched = patched+1
        end
    end

    if patched > 0 then
        Addon.Print(string.format("Applied |cff66b3ff%s|r to %d Fojji ForeverAura pack%s.",fontName,patched,patched == 1 and "" or "s"))
        Addon.Print("Type |cff66b3ff/reload|r to apply font changes.")
    else
        Addon.Print("No supported Fojji ForeverAura packs were found.")
    end
end

FojjiCore.SCALE_MIN, FojjiCore.SCALE_MAX = 0.5, 2

function FojjiCore:GetInstalledPackGroups()
    local list, seen = {}, {}

    for _,groupName in ipairs(self.fontPatchGroups or {}) do
        local found = self:FindAuraName(groupName)
        local data = found and ForeverAuras.GetData(found)

        if data and not data.parent and not seen[found] then
            seen[found] = true
            list[#list+1] = found
        end
    end

    local function isClass(name) return name:find(" UI %[") ~= nil end
    table.sort(list, function(a, b)
        local ca, cb = isClass(a), isClass(b)
        if ca ~= cb then return ca end
        return a:lower() < b:lower()
    end)

    return list
end

function FojjiCore:GetGroupScale(groupName)
    local found = self:FindAuraName(groupName)
    local data = found and ForeverAuras.GetData(found)

    if not data then
        return nil
    end

    return tonumber(data.scale) or 1
end

function FojjiCore:SetGroupScale(groupName,scale,quiet)
    local found = self:FindAuraName(groupName)
    local data = found and ForeverAuras.GetData(found)

    if not data or data.parent then
        return false
    end

    scale = math.floor(math.max(self.SCALE_MIN,math.min(self.SCALE_MAX,tonumber(scale) or 1))*100+0.5)/100
    data.scale = scale

    local saved = ForeverAurasSaved and ForeverAurasSaved.displays and ForeverAurasSaved.displays[found]

    if saved then
        saved.scale = scale
    end

    local region = ForeverAuras.GetRegion and ForeverAuras.GetRegion(found)

    if region and region.SetScale then
        region:SetScale(scale)
    end

    if not quiet then
        Addon.Print(string.format("Scale |cff66b3ff%d%%|r applied to |cff66b3ff%s|r.",math.floor(scale*100+0.5),found))
    end

    return true
end

function FojjiCore:SetScaleForAll(scale)
    local count = 0

    for _,groupName in ipairs(self:GetInstalledPackGroups()) do
        if self:SetGroupScale(groupName,scale,true) then
            count = count+1
        end
    end

    if count > 0 then
        Addon.Print(string.format("Scale |cff66b3ff%d%%|r applied to %d Fojji ForeverAuras pack%s.",math.floor((tonumber(scale) or 1)*100+0.5),count,count == 1 and "" or "s"))
    else
        Addon.Print("No supported Fojji ForeverAuras packs were found.")
    end

    return count
end

function FojjiCore:InitForeverAurasOptionsHook()
    if self.waOptionsHooked then
        return
    end

    if not ForeverAuras then
        return
    end

    self.waOptionsHooked = true

    if ForeverAuras.OpenOptions then
        hooksecurefunc(ForeverAuras,"OpenOptions",function()
            ForeverAuras.ScanEvents("WA_FJI_OPTIONS_OPENED")
        end)
    end
end

FojjiCore:InitForeverAurasOptionsHook()

SLASH_FJIARCANEBOMB1 = "/ab"

SlashCmdList["FJIARCANEBOMB"] = function()
    ForeverAuras.ScanEvents("WA_FJI_ABT_TOGGLE")
end
