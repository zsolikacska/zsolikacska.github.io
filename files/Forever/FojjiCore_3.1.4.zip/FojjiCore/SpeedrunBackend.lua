local _, Addon = ...

FojjiCoreNS = Addon
Addon.IsForever = false
Addon.AuraAPI = WeakAuras

function Addon.Print(message)
    print("|cff66b3ffFojji|r|cffff4444Core|r: " .. tostring(message))
end
