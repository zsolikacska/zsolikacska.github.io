local Addon = FojjiCoreNS
if not Addon then return end
local FDJ = Addon.DJ

local Pins = {}
FDJ.Pins = Pins

local L = FDJ.L
local Book = FDJ.QuestBook
local Quests = FDJ.Quests

Pins.placing = nil
Pins.active = nil

local function same(a, b)
    return a and b and math.abs(a - b) < 0.0005
end

function Pins.Native()
    if not (C_Map.HasUserWaypoint and C_Map.HasUserWaypoint()) then return nil end
    local point = C_Map.GetUserWaypoint and C_Map.GetUserWaypoint()
    if not point or not point.position then return nil end
    local pos = point.position
    local x, y = pos.x, pos.y
    if (not x or not y) and pos.GetXY then x, y = pos:GetXY() end
    if not x or not y then return nil end
    return point.uiMapID, x, y
end

function Pins.Has(qid)
    local active = Pins.active
    if not active or active.qid ~= qid then return false end
    local m, x, y = Pins.Native()
    return m == active.m and same(x, active.x) and same(y, active.y)
end

function Pins.ActiveQuest()
    local active = Pins.active
    if active and Pins.Has(active.qid) then return active.qid end
    return nil
end

function Pins.OpenMap(mapID)
    if FDJ.InCombat() then
        FDJ.Print(L.MAP_IN_COMBAT)
        return false
    end
    if mapID and FDJ.InstanceMap and FDJ.InstanceMap.ShowWorld then FDJ.InstanceMap.ShowWorld() end
    if C_Map.OpenWorldMap then
        C_Map.OpenWorldMap(mapID)
    elseif OpenWorldMap then
        OpenWorldMap(mapID)
    else
        if not WorldMapFrame:IsShown() then ToggleWorldMap() end
        if mapID then WorldMapFrame:SetMapID(mapID) end
    end
    if mapID and WorldMapFrame and WorldMapFrame:IsShown() and WorldMapFrame:GetMapID() ~= mapID then
        WorldMapFrame:SetMapID(mapID)
    end
    return true
end

function Pins.SetNative(mapID, x, y)
    if not (C_Map.SetUserWaypoint and UiMapPoint) then return false end
    if C_Map.CanSetUserWaypointOnMap and not C_Map.CanSetUserWaypointOnMap(mapID) then
        FDJ.Print(L.NO_WAYPOINT)
        return false
    end
    C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(mapID, x, y))
    if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
    return true
end

local function pinAt(qid, mapID, x, y, quiet)
    if not Pins.SetNative(mapID, x, y) then return false end
    Pins.active = { qid = qid, m = mapID, x = x, y = y }
    FDJ:Emit("FDJ_PINS")
    if not quiet then
        FDJ.Print(L.PIN_SET:format(FDJ.Q(Quests.Title(qid)), FDJ.Hi(FDJ.MapName(mapID)),
            FDJ.Paint("accent", ("%.1f, %.1f"):format(x * 100, y * 100))))
    end
    return true
end

function Pins.BeginPlacing(qid)
    local q = Book[qid]
    if not q then return end
    Pins.placing = qid
    FDJ:Emit("FDJ_PLACING", qid)
    local zone = FDJ.ZoneMap(q.at)
    if not zone and q.by and FDJ.Givers[q.by] then zone = FDJ.ZoneMap(FDJ.Givers[q.by][1]) end
    Pins.OpenMap(zone or C_Map.GetBestMapForUnit("player"))
end

function Pins.StopPlacing()
    if Pins.placing then
        Pins.placing = nil
        FDJ:Emit("FDJ_PLACING", nil)
    end
end

function Pins.Place(mapID, x, y)
    local qid = Pins.placing
    if not qid then return false end
    Pins.StopPlacing()
    Quests.Remember(qid, mapID, x, y, "pin")
    pinAt(qid, mapID, x, y)
    return true
end

function Pins.Pin(qid, stay)
    local spot = Quests.NextStep(qid) or Quests.Spot(qid)
    if spot then
        pinAt(qid, spot.m, spot.x, spot.y)
        return true
    end
    Pins.BeginPlacing(qid)
    return false
end

function Pins.Remove(qid)
    if Pins.Has(qid) and C_Map.ClearUserWaypoint then C_Map.ClearUserWaypoint() end
    Pins.active = nil
    FDJ:Emit("FDJ_PINS")
end

function Pins.Toggle(qid)
    if Pins.Has(qid) then
        Pins.Remove(qid)
    else
        Pins.Pin(qid)
    end
end

function Pins.Hyperlink()
    if not C_Map.GetUserWaypointHyperlink then return nil end
    local ok, link = pcall(C_Map.GetUserWaypointHyperlink)
    if ok and type(link) == "string" and link ~= "" then return link end
    return nil
end

function Pins.ShareLine(qid)
    local m, x, y = Pins.Native()
    if not m then return nil end
    qid = qid or Pins.ActiveQuest()
    local where = ("%s %.1f, %.1f"):format(FDJ.MapName(m), x * 100, y * 100)
    local link = Pins.Hyperlink()
    local line = link and (link .. "  (" .. where .. ")") or (L.PIN_SHARE_PREFIX .. " " .. where)
    if qid and Pins.Has(qid) then line = line .. "  " .. L.PIN_SHARE_FOR:format(Quests.Title(qid)) end
    return line
end

function Pins.Share(qid, toChatBox)
    local line = Pins.ShareLine(qid)
    if not line then
        FDJ.Print(L.NO_PIN_TO_SHARE)
        return false
    end
    if not toChatBox and FDJ.GroupChannel() then
        FDJ.Say(line)
        return true
    end
    if not FDJ.OpenChat(line) then FDJ.Print(line) end
    return true
end

function Pins.WaypointAt(mapID, x, y)
    if not Pins.SetNative(mapID, x, y) then return false end
    Pins.active = nil
    FDJ:Emit("FDJ_PINS")
    FDJ.Print(L.WAYPOINT_SET:format(FDJ.Hi(FDJ.MapName(mapID)), FDJ.Paint("accent", ("%.1f, %.1f"):format(x * 100, y * 100))))
    return true
end

FDJ:On("USER_WAYPOINT_UPDATED", function()
    FDJ.Debounce("nativepin", 0.1, function() FDJ:Emit("FDJ_PINS") end)
end)

FDJ:On("PLAYER_LOGIN", function()
    local old = FDJ.db and FDJ.db.pins
    if type(old) ~= "table" or next(old) == nil then return end
    for qid, pin in pairs(old) do
        if type(pin) == "table" and pin.m and pin.x and pin.y then Quests.Remember(qid, pin.m, pin.x, pin.y, "pin", true) end
    end
    wipe(old)
end)

local function playerAt()
    local mapID = C_Map.GetBestMapForUnit("player")
    local pos = mapID and C_Map.GetPlayerMapPosition(mapID, "player")
    if not pos then return nil end
    local x, y = FDJ.XY(pos)
    if FDJ.Secret(x) then return nil end
    return mapID, x, y
end

function Pins.PlanPickup(d)
    local stops = {}
    for _, qid in ipairs(Quests.ForDungeon(d)) do
        if Quests.Status(qid) == "open" then
            local spot = Quests.Spot(qid)
            if spot then stops[#stops + 1] = { m = spot.m, x = spot.x, y = spot.y, label = Quests.Title(qid) } end
        end
    end
    if #stops == 0 then
        FDJ.Print(L.PLAN_EMPTY)
        return nil
    end
    local merged = {}
    for _, stop in ipairs(stops) do
        local hit
        for _, m in ipairs(merged) do
            if m.m == stop.m and math.abs(m.x - stop.x) < 0.01 and math.abs(m.y - stop.y) < 0.01 then hit = m end
        end
        if hit then
            hit.label = hit.label .. " + " .. stop.label
        else
            merged[#merged + 1] = stop
        end
    end
    local mapID, px, py = playerAt()
    local ordered, cm, cx, cy = {}, mapID, px or 0.5, py or 0.5
    while #merged > 0 do
        local best, bestCost
        for i, stop in ipairs(merged) do
            local cost = (stop.m == cm and 0 or 10) + math.sqrt((stop.x - cx) ^ 2 + (stop.y - cy) ^ 2)
            if not bestCost or cost < bestCost then best, bestCost = i, cost end
        end
        local stop = table.remove(merged, best)
        ordered[#ordered + 1] = stop
        cm, cx, cy = stop.m, stop.x, stop.y
    end
    local route = FDJ.Routes.Create("world", d.key, FDJ.RouteTitle(L.PICKUP_NAME, FDJ.DungeonTitle(d)))
    for _, stop in ipairs(ordered) do
        route.points[#route.points + 1] = { m = stop.m, x = stop.x, y = stop.y, label = FDJ.Clip(stop.label, 80) }
    end
    FDJ:Emit("FDJ_ROUTES")
    return route
end
